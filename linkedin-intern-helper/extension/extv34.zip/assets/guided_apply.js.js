(function(){if (window !== window.top) {
  console.log("[InternHelper] BLOCKED: not top window →", window.location.href);
  throw new Error("[InternHelper] Iframe execution blocked.");
}
console.log("[InternHelper] Content script loaded (Simplify-Style)");
function setNativeValue(element, value) {
  const proto = element.__proto__;
  const descriptor = Object.getOwnPropertyDescriptor(proto, "value");
  if (!descriptor || !descriptor.set) return;
  descriptor.set.call(element, value);
  element.dispatchEvent(new Event("input", { bubbles: true }));
  element.dispatchEvent(new Event("change", { bubbles: true }));
  element.dispatchEvent(new Event("blur", { bubbles: true }));
}
function getLabelText(field) {
  var _a;
  if (field.id) {
    const label = document.querySelector(`label[for="${field.id}"]`);
    if (label == null ? void 0 : label.innerText) return label.innerText.toLowerCase().trim();
  }
  const aria = field.getAttribute("aria-label");
  if (aria) return aria.toLowerCase().trim();
  const nearest = (_a = field.closest("div")) == null ? void 0 : _a.querySelector("label");
  if (nearest == null ? void 0 : nearest.innerText) return nearest.innerText.toLowerCase().trim();
  return (field.placeholder || "").toLowerCase().trim();
}
function waitForModal(timeout = 8e3) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    const interval = setInterval(() => {
      const modal = document.querySelector('div[role="dialog"]');
      if (modal) {
        clearInterval(interval);
        console.log("[InternHelper] Modal detected.");
        resolve(modal);
      }
      if (Date.now() - start > timeout) {
        clearInterval(interval);
        reject(new Error("Modal not found within " + timeout + "ms"));
      }
    }, 300);
  });
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function fillPhone(input, profile) {
  if (input.value && input.value.trim() !== "") return;
  let phone = profile.phone_number || profile.phone || "";
  if (!phone) {
    phone = "9" + Math.floor(Math.random() * 1e9).toString().padStart(9, "0");
    console.log("[InternHelper] Phone not in profile — generated:", phone);
  }
  setNativeValue(input, phone);
  console.log("[InternHelper] Filled phone →", phone);
}
function fillEmail(input, profile) {
  if (input.value && input.value.trim() !== "") return;
  const val = profile.email || "";
  if (!val) return;
  setNativeValue(input, val);
  console.log("[InternHelper] Filled email →", val);
}
function fillFirstName(input, profile) {
  if (input.value && input.value.trim() !== "") return;
  const val = profile.first_name || "";
  if (!val) return;
  setNativeValue(input, val);
  console.log("[InternHelper] Filled first name →", val);
}
function fillLastName(input, profile) {
  if (input.value && input.value.trim() !== "") return;
  const val = profile.last_name || "";
  if (!val) return;
  setNativeValue(input, val);
  console.log("[InternHelper] Filled last name →", val);
}
function fillCity(input, profile) {
  if (input.value && input.value.trim() !== "") return;
  const val = profile.city || profile.location || "";
  if (!val) return;
  setNativeValue(input, val);
  console.log("[InternHelper] Filled city →", val);
}
function fillLinkedIn(input, profile) {
  if (input.value && input.value.trim() !== "") return;
  const val = profile.linkedin_url || "";
  if (!val) return;
  setNativeValue(input, val);
  console.log("[InternHelper] Filled LinkedIn →", val);
}
function fillExperience(input, profile) {
  var _a;
  if (input.value && input.value.trim() !== "") return;
  const val = ((_a = profile.years_of_experience) == null ? void 0 : _a.toString()) || "";
  if (!val) return;
  setNativeValue(input, val);
  console.log("[InternHelper] Filled experience →", val);
}
function fillModal(modal, profile) {
  const fields = modal.querySelectorAll("input, textarea, select");
  console.log("[InternHelper] fillModal: found", fields.length, "fields in modal");
  fields.forEach((field) => {
    const label = getLabelText(field);
    console.log("[InternHelper] Field label:", JSON.stringify(label), "| type:", field.type, "| id:", field.id);
    if (label.includes("phone") || label.includes("mobile") || label.includes("contact number") || field.type === "tel") {
      fillPhone(field, profile);
      return;
    }
    if (label.includes("email") || field.type === "email") {
      fillEmail(field, profile);
      return;
    }
    if (label.includes("first name")) {
      fillFirstName(field, profile);
      return;
    }
    if (label.includes("last name")) {
      fillLastName(field, profile);
      return;
    }
    if (label.includes("city") || label.includes("location")) {
      fillCity(field, profile);
      return;
    }
    if (label.includes("linkedin")) {
      fillLinkedIn(field, profile);
      return;
    }
    if (label.includes("experience") || label.includes("years")) {
      fillExperience(field, profile);
      return;
    }
    if (!field.value || field.value.trim() === "") {
      console.log("[InternHelper] Unknown empty field (skipping):", label, field.type, field.id, field.name);
    }
  });
}
function clickNext(modal) {
  var _a;
  const btn = modal.querySelector('button[aria-label="Continue to next step"]') || modal.querySelector('button[aria-label="Next"]') || modal.querySelector('button[aria-label*="next" i]') || modal.querySelector('button[aria-label*="review" i]') || [...modal.querySelectorAll("button")].find((b) => {
    const t = (b.innerText || "").toLowerCase().trim();
    return (t === "next" || t === "review" || t.includes("continue")) && !b.disabled;
  });
  if (btn) {
    console.log("[InternHelper] Clicking Next/Review:", ((_a = btn.innerText) == null ? void 0 : _a.trim()) || btn.getAttribute("aria-label"));
    btn.click();
    return true;
  }
  console.log("[InternHelper] No Next button found in modal.");
  return false;
}
function isSubmitScreen(modal) {
  return !!(modal.querySelector('button[aria-label*="Submit" i]') || modal.querySelector('button[aria-label*="submit application" i]') || [...modal.querySelectorAll("button")].find(
    (b) => (b.innerText || "").toLowerCase().includes("submit application")
  ));
}
async function runEasyApply(profile) {
  console.log("[InternHelper] runEasyApply() triggered.");
  const easyApplyBtn = document.querySelector('button[aria-label*="Easy Apply" i]') || [...document.querySelectorAll("button")].find(
    (b) => (b.innerText || "").trim().toLowerCase() === "easy apply" && !b.disabled
  );
  if (!easyApplyBtn) {
    console.log("[InternHelper] Easy Apply button not found on this page.");
    return;
  }
  console.log("[InternHelper] Easy Apply button found. Clicking...");
  easyApplyBtn.click();
  let modal;
  try {
    modal = await waitForModal(8e3);
  } catch (e) {
    console.warn("[InternHelper] Modal did not appear:", e.message);
    return;
  }
  let step = 0;
  const MAX_STEPS = 10;
  while (step < MAX_STEPS) {
    step++;
    console.log("[InternHelper] Modal step", step);
    modal = document.querySelector('div[role="dialog"]');
    if (!modal) {
      console.log("[InternHelper] Modal closed. Done.");
      break;
    }
    if (isSubmitScreen(modal)) {
      console.log("[InternHelper] ✅ Submit screen reached. Stopping automation. Let user review and submit.");
      const submitBtn = modal.querySelector('button[aria-label*="Submit" i]') || [...modal.querySelectorAll("button")].find(
        (b) => (b.innerText || "").toLowerCase().includes("submit application")
      );
      if (submitBtn) {
        submitBtn.style.outline = "3px solid #00b300";
        submitBtn.style.boxShadow = "0 0 12px #00b300";
      }
      break;
    }
    fillModal(modal, profile);
    await sleep(600);
    const clicked = clickNext(modal);
    if (!clicked) {
      console.log("[InternHelper] No Next button — waiting 2s and retrying.");
      await sleep(2e3);
      modal = document.querySelector('div[role="dialog"]');
      if (!modal) break;
      if (isSubmitScreen(modal)) {
        console.log("[InternHelper] ✅ Submit screen detected after wait. Stopping.");
        break;
      }
      const retryNext = clickNext(modal);
      if (!retryNext) {
        console.log("[InternHelper] Still no Next button after retry. Aborting.");
        break;
      }
    }
    await sleep(1500);
  }
  console.log("[InternHelper] runEasyApply() complete after", step, "step(s).");
}
let _sessionProfile = null;
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "START_AUTOFILL" || message.type === "START_GUIDED_APPLY") {
    _sessionProfile = message.profile || {};
    console.log("[InternHelper] Received profile:", _sessionProfile);
    runEasyApply(_sessionProfile).then(() => sendResponse({ success: true })).catch((e) => {
      console.error("[InternHelper] runEasyApply error:", e);
      sendResponse({ success: false, error: e.message });
    });
    return true;
  }
});
(async () => {
  const stored = await chrome.storage.local.get(["guidedProfile", "guidedSessionActive"]);
  if (!stored.guidedSessionActive || !stored.guidedProfile) return;
  console.log("[InternHelper] Starting session.");
  _sessionProfile = stored.guidedProfile;
  await sleep(1500);
  await runEasyApply(_sessionProfile);
})();
//# sourceMappingURL=guided_apply.js.js.map
})()