const BASE_URL = "https://internhelper-backend.onrender.com";
const USER_ID = "default-user";
const fetchApi = async (endpoint, options = {}) => {
  try {
    const response = await fetch(`${BASE_URL}${endpoint}`, {
      headers: {
        "Content-Type": "application/json",
        ...options.headers || {}
      },
      ...options
    });
    if (!response.ok) {
      console.error(`[InternHelper API] Server Error (${response.status}) on ${endpoint}`);
      throw new Error(`Server returned ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error(`[InternHelper API] Network/Fetch Error on ${endpoint}:`, error);
    throw error;
  }
};
const saveProfile = async (profileData, resumeFile) => {
  try {
    let resumePayload = null;
    if (resumeFile) {
      const base64Resume = await fileToBase64(resumeFile);
      resumePayload = {
        name: resumeFile.name,
        type: resumeFile.type,
        data: base64Resume,
        lastUpdated: (/* @__PURE__ */ new Date()).toISOString()
      };
      await chrome.storage.local.set({ userResume: resumePayload });
    }
    const response = await fetchApi("/profile", {
      method: "POST",
      body: JSON.stringify({
        user_id: USER_ID,
        ...profileData
      })
    });
    if (response.success) {
      console.log("[InternHelper] Profile Successfully Pushed to Backend Database.");
      return { success: true };
    } else {
      throw new Error("Backend explicitly returned failure");
    }
  } catch (err) {
    console.error("[InternHelper] Database Save Failed:", err);
    return { success: false, error: err.message };
  }
};
const getProfile = async () => {
  try {
    console.log("[InternHelper] Fetching profile from Render API...");
    const profileResponse = await fetchApi(`/profile?user_id=${USER_ID}`);
    console.log("[InternHelper] API returned:", profileResponse);
    const localData = await chrome.storage.local.get(["userResume"]);
    const mappedProfile = profileResponse ? {
      full_name: profileResponse.first_name ? `${profileResponse.first_name} ${profileResponse.last_name || ""}`.trim() : "",
      phone: profileResponse.phone || "",
      location: profileResponse.city || "",
      linkedin_url: profileResponse.linkedin_url || "",
      portfolio_url: profileResponse.portfolio_url || "",
      experience: profileResponse.experience || "",
      yoe: profileResponse.experience || "",
      degree: profileResponse.degree || "",
      major: profileResponse.major || "",
      university: profileResponse.university || "",
      graduation_year: profileResponse.graduation_year || "",
      year_of_study: profileResponse.year_of_study || profileResponse.current_year || "",
      // Fallback for transition
      gpa: profileResponse.gpa || "",
      authorized_to_work: profileResponse.authorized_to_work ?? profileResponse.work_authorized ?? true,
      open_to_relocation: profileResponse.open_to_relocation ?? profileResponse.relocation ?? false,
      stipend: profileResponse.stipend || profileResponse.expected_stipend || "",
      availability_type: profileResponse.availability_type || "",
      available_from: profileResponse.available_from || "",
      notice_period: profileResponse.notice_period || "",
      skills: profileResponse.skills || "",
      experience_summary: profileResponse.experience_summary || "",
      projects: profileResponse.projects || [],
      resume_filename: profileResponse.resume_filename || "",
      metadata: profileResponse.metadata || {}
    } : {};
    return {
      profile: mappedProfile,
      resume: localData.userResume || null
    };
  } catch (err) {
    console.error("[InternHelper] Database Fetch Failed, returning empty profile fallback.", err);
    return { profile: {}, resume: null };
  }
};
const fileToBase64 = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });
};
const base64ToBlob = (base64, type = "application/pdf") => {
  const arr = base64.split(",");
  const mime = arr[0].match(/:(.*?);/)[1] || type;
  const bstr = atob(arr[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new Blob([u8arr], { type: mime });
};
export {
  USER_ID as U,
  base64ToBlob as b,
  fetchApi as f,
  getProfile as g,
  saveProfile as s
};
//# sourceMappingURL=profileService-BC89jDf9.js.map
