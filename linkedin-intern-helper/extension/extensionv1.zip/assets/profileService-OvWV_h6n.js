const saveProfile = async (profileData, resumeFile) => {
  try {
    const storageData = { userProfile: profileData };
    if (resumeFile) {
      const base64Resume = await fileToBase64(resumeFile);
      storageData.userResume = {
        name: resumeFile.name,
        type: resumeFile.type,
        data: base64Resume,
        lastUpdated: (/* @__PURE__ */ new Date()).toISOString()
      };
    }
    await chrome.storage.local.set(storageData);
    console.log("[InternHelper] Profile Saved:", profileData);
    return { success: true };
  } catch (err) {
    console.error("[InternHelper] Save Failed:", err);
    return { success: false, error: err.message };
  }
};
const getProfile = async () => {
  const res = await chrome.storage.local.get(["userProfile", "userResume"]);
  return {
    profile: res.userProfile || {},
    resume: res.userResume || null
  };
};
const fileToBase64 = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });
};
const base64ToBlob = (base64, type = "application/pdf") => {
  const arr = base64.split(",");
  const mime = arr[0].match(/:(.*?);/)[1] || type;
  const bstr = atob(arr[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new Blob([u8arr], { type: mime });
};
export {
  base64ToBlob as b,
  getProfile as g,
  saveProfile as s
};
//# sourceMappingURL=profileService-OvWV_h6n.js.map
