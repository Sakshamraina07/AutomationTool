(function(){console.log("[InternHelper] Content script loaded");
function setNativeValue(element, value) {
  const proto = Object.getPrototypeOf(element);
  const descriptor = Object.getOwnPropertyDescriptor(proto, "value");
  if (!descriptor || !descriptor.set) return;
  descriptor.set.call(element, value);
  element.dispatchEvent(new Event("input", { bubbles: true }));
  element.dispatchEvent(new Event("change", { bubbles: true }));
  element.dispatchEvent(new Event("blur", { bubbles: true }));
}
function getLabelText(field) {
  var _a;
  if (field.id) {
    const label = document.querySelector(`label[for="${field.id}"]`);
    if (label == null ? void 0 : label.innerText) return label.innerText.toLowerCase().trim();
  }
  const aria = field.getAttribute("aria-label");
  if (aria) return aria.toLowerCase().trim();
  const nearest = (_a = field.closest("div")) == null ? void 0 : _a.querySelector("label");
  if (nearest == null ? void 0 : nearest.innerText) return nearest.innerText.toLowerCase().trim();
  return (field.placeholder || field.name || "").toLowerCase().trim();
}
let _profile = {};
let _fillInProgress = false;
function fillModal(modal) {
  if (_fillInProgress) return;
  _fillInProgress = true;
  const fields = modal.querySelectorAll("input:not([type='hidden']), textarea, select");
  console.log("[InternHelper] fillModal: found", fields.length, "fields in modal");
  fields.forEach((field) => {
    var _a, _b, _c, _d, _e, _f, _g;
    const label = getLabelText(field);
    if (!label) return;
    console.log("[InternHelper] Field:", JSON.stringify(label), "| type:", field.type);
    if (label.includes("phone") || label.includes("mobile") || label.includes("contact") || field.type === "tel") {
      if (!field.value || !field.value.trim()) {
        const phone = _profile.phone_number || _profile.phone || "9" + Math.floor(Math.random() * 1e9).toString().padStart(9, "0");
        setNativeValue(field, phone);
        console.log("[InternHelper] Filled phone →", phone);
      }
    } else if (label.includes("email") || field.type === "email") {
      if (_profile.email && !((_a = field.value) == null ? void 0 : _a.trim()))
        setNativeValue(field, _profile.email);
    } else if (label.includes("first name")) {
      if (_profile.first_name && !((_b = field.value) == null ? void 0 : _b.trim()))
        setNativeValue(field, _profile.first_name);
    } else if (label.includes("last name")) {
      if (_profile.last_name && !((_c = field.value) == null ? void 0 : _c.trim()))
        setNativeValue(field, _profile.last_name);
    } else if (label.includes("city") || label.includes("location")) {
      if ((_profile.city || _profile.location) && !((_d = field.value) == null ? void 0 : _d.trim()))
        setNativeValue(field, _profile.city || _profile.location);
    } else if (label.includes("linkedin")) {
      if (_profile.linkedin_url && !((_e = field.value) == null ? void 0 : _e.trim()))
        setNativeValue(field, _profile.linkedin_url);
    } else if (label.includes("experience") || label.includes("years")) {
      if (_profile.years_of_experience && !((_f = field.value) == null ? void 0 : _f.trim()))
        setNativeValue(field, _profile.years_of_experience.toString());
    } else if (label.includes("salary") || label.includes("stipend") || label.includes("ctc")) {
      if (_profile.expected_stipend && !((_g = field.value) == null ? void 0 : _g.trim()))
        setNativeValue(field, _profile.expected_stipend.toString());
    }
  });
  setTimeout(() => {
    var _a;
    const currentModal = document.querySelector('div[role="dialog"]');
    if (!currentModal) {
      _fillInProgress = false;
      return;
    }
    const submitBtn = currentModal.querySelector('button[aria-label*="Submit" i]') || [...currentModal.querySelectorAll("button")].find(
      (b) => (b.innerText || "").toLowerCase().includes("submit application")
    );
    if (submitBtn) {
      console.log("[InternHelper] ✅ Submit screen. Highlighting button. User should click.");
      submitBtn.style.outline = "3px solid #00b300";
      submitBtn.style.boxShadow = "0 0 16px rgba(0,179,0,0.7)";
      _fillInProgress = false;
      return;
    }
    const nextBtn = currentModal.querySelector('button[aria-label="Continue to next step"]') || currentModal.querySelector('button[aria-label="Next"]') || currentModal.querySelector('button[aria-label*="next" i]') || currentModal.querySelector('button[aria-label*="review" i]') || [...currentModal.querySelectorAll("button")].find((b) => {
      if (b.disabled) return false;
      const t = (b.innerText || "").toLowerCase().trim();
      return t === "next" || t === "review" || t === "continue";
    });
    if (nextBtn) {
      console.log("[InternHelper] Clicking:", ((_a = nextBtn.innerText) == null ? void 0 : _a.trim()) || nextBtn.getAttribute("aria-label"));
      nextBtn.click();
    } else {
      console.log("[InternHelper] No Next button found yet.");
    }
    _fillInProgress = false;
  }, 800);
}
let _lastModalKey = null;
function startObserver() {
  const observer = new MutationObserver(() => {
    const modal = document.querySelector('div[role="dialog"]');
    if (!modal) {
      _lastModalKey = null;
      _fillInProgress = false;
      return;
    }
    const key = modal.innerHTML.length;
    if (key === _lastModalKey) return;
    _lastModalKey = key;
    console.log("[InternHelper] Modal change detected. Scheduling fill...");
    setTimeout(() => fillModal(modal), 500);
  });
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  console.log("[InternHelper] MutationObserver watching for modal...");
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "START_AUTOFILL" || message.type === "START_GUIDED_APPLY") {
    _profile = message.profile || {};
    console.log("[InternHelper] Profile received. Observer active.");
    sendResponse({ success: true });
  }
  return false;
});
(async () => {
  const stored = await chrome.storage.local.get(["guidedProfile", "guidedSessionActive"]);
  if (stored.guidedSessionActive && stored.guidedProfile) {
    _profile = stored.guidedProfile;
    console.log("[InternHelper] Session active. Profile loaded from storage.");
  }
  startObserver();
  const existingModal = document.querySelector('div[role="dialog"]');
  if (existingModal) {
    console.log("[InternHelper] Modal already present on load. Filling...");
    setTimeout(() => fillModal(existingModal), 500);
  }
})();
//# sourceMappingURL=guided_apply.js.js.map
})()