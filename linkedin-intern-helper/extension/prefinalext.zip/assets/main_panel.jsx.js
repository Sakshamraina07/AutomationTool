import { r as reactExports, j as jsxRuntimeExports, A as App, c as client, R as React } from "./App.js";
const SidePanel = () => {
  const [isOpen, setIsOpen] = reactExports.useState(false);
  const togglePanel = () => {
    setIsOpen(!isOpen);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `ih-panel-container ${isOpen ? "open" : "collapsed"}`, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "ih-toggle-btn", onClick: togglePanel, children: isOpen ? "›" : "‹" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "ih-panel-content", children: /* @__PURE__ */ jsxRuntimeExports.jsx(App, {}) })
  ] });
};
const panelStyles = '/* Panel Container */\r\n.ih-panel-container {\r\n    position: fixed;\r\n    top: 0;\r\n    right: 0;\r\n    height: 100vh;\r\n    width: 420px;\r\n    background: #f8fafc;\r\n    z-index: 2147483647;\r\n    /* Max z-index */\r\n    box-shadow: -10px 0 30px rgba(0, 0, 0, 0.15);\r\n    transform: translateX(0);\r\n    transition: transform 0.4s cubic-bezier(0.25, 1, 0.5, 1);\r\n    display: flex;\r\n    flex-direction: column;\r\n    font-family: -apple-system, system-ui, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;\r\n    border-left: 1px solid rgba(0, 0, 0, 0.05);\r\n}\r\n\r\n.ih-panel-container.collapsed {\r\n    transform: translateX(420px);\r\n    box-shadow: none;\r\n}\r\n\r\n/* Toggle Button */\r\n.ih-toggle-btn {\r\n    position: absolute;\r\n    left: -50px;\r\n    top: 100px;\r\n    /* Lower it a bit */\r\n    width: 50px;\r\n    height: 50px;\r\n    background: white;\r\n    border-radius: 12px 0 0 12px;\r\n    display: flex;\r\n    align-items: center;\r\n    justify-content: center;\r\n    cursor: pointer;\r\n    box-shadow: -4px 4px 12px rgba(0, 0, 0, 0.1);\r\n    border: 1px solid rgba(0, 0, 0, 0.05);\r\n    border-right: none;\r\n    z-index: 2147483648;\r\n    transition: all 0.2s cubic-bezier(0.25, 0.8, 0.25, 1);\r\n    overflow: hidden;\r\n}\r\n\r\n.ih-toggle-btn:hover {\r\n    width: 60px;\r\n    left: -60px;\r\n    background: #f1f5f9;\r\n}\r\n\r\n/* Icon in toggle button */\r\n.ih-toggle-icon {\r\n    font-size: 24px;\r\n    color: #0a66c2;\r\n    /* LinkedIn Blue */\r\n    transition: transform 0.3s;\r\n}\r\n\r\n.ih-panel-container.collapsed .ih-toggle-btn {\r\n    background: #0a66c2;\r\n}\r\n\r\n.ih-panel-container.collapsed .ih-toggle-icon {\r\n    color: white;\r\n    transform: rotate(180deg);\r\n}\r\n\r\n\r\n/* Internal Content Wrapper */\r\n.ih-panel-content {\r\n    flex: 1;\r\n    overflow-y: auto;\r\n    height: 100%;\r\n    padding: 0;\r\n    /* Let App.css handle padding */\r\n    position: relative;\r\n}';
const appStyles = ":host,\r\n:root {\r\n    --bg: #111111;\r\n    --card-bg: #1a1a1a;\r\n    --accent: #06b6d4;\r\n    /* Electric Cyan */\r\n    --accent-hover: #0891b2;\r\n    --text: #f9fafb;\r\n    --text-muted: #9ca3af;\r\n    --border: #2e2e2e;\r\n    --danger: #ef4444;\r\n    --warning-bg: rgba(245, 158, 11, 0.1);\r\n    --warning-text: #f59e0b;\r\n\r\n    --shadow: 0 4px 20px rgba(0, 0, 0, 0.5);\r\n    --radius-sm: 8px;\r\n    --radius-md: 12px;\r\n    --radius-lg: 16px;\r\n}\r\n\r\nbody,\r\n#h-root {\r\n    margin: 0;\r\n    font-family: 'Inter', -apple-system, system-ui, sans-serif;\r\n    background-color: var(--bg);\r\n    color: var(--text);\r\n    width: 380px;\r\n    min-height: 500px;\r\n    overflow-x: hidden;\r\n}\r\n\r\n.popup-container {\r\n    display: flex;\r\n    flex-direction: column;\r\n    min-height: 500px;\r\n}\r\n\r\n/* Header */\r\n.header {\r\n    padding: 24px;\r\n    border-bottom: 1px solid var(--border);\r\n    display: flex;\r\n    flex-direction: column;\r\n    gap: 4px;\r\n}\r\n\r\n.header h1 {\r\n    margin: 0;\r\n    font-size: 22px;\r\n    font-weight: 700;\r\n    letter-spacing: -0.5px;\r\n}\r\n\r\n.tagline {\r\n    font-size: 13px;\r\n    color: var(--text-muted);\r\n}\r\n\r\n/* Tabs */\r\n.tabs {\r\n    display: flex;\r\n    padding: 0 16px;\r\n    gap: 24px;\r\n    border-bottom: 1px solid var(--border);\r\n}\r\n\r\n.tab-btn {\r\n    background: none;\r\n    border: none;\r\n    color: var(--text-muted);\r\n    padding: 16px 0;\r\n    font-size: 14px;\r\n    font-weight: 600;\r\n    cursor: pointer;\r\n    position: relative;\r\n    transition: color 0.2s;\r\n}\r\n\r\n.tab-btn.active {\r\n    color: var(--accent);\r\n}\r\n\r\n.tab-btn.active::after {\r\n    content: '';\r\n    position: absolute;\r\n    bottom: -1px;\r\n    left: 0;\r\n    right: 0;\r\n    height: 2px;\r\n    background: var(--accent);\r\n}\r\n\r\n/* Main Content */\r\n.main-content {\r\n    flex: 1;\r\n    padding: 20px;\r\n    display: flex;\r\n    flex-direction: column;\r\n    gap: 16px;\r\n}\r\n\r\n.section-title {\r\n    font-size: 16px;\r\n    font-weight: 600;\r\n    margin-bottom: 12px;\r\n}\r\n\r\n/* Warning Banner */\r\n.warning-banner {\r\n    background: var(--warning-bg);\r\n    color: var(--warning-text);\r\n    padding: 12px 16px;\r\n    border-radius: var(--radius-md);\r\n    font-size: 13px;\r\n    font-weight: 500;\r\n    margin-bottom: 8px;\r\n    display: flex;\r\n    align-items: center;\r\n    gap: 8px;\r\n    border: 1px solid rgba(245, 158, 11, 0.2);\r\n}\r\n\r\n/* Workflow Cards */\r\n.workflow-step {\r\n    background: var(--card-bg);\r\n    border: 1px solid var(--border);\r\n    border-radius: var(--radius-md);\r\n    padding: 16px;\r\n    display: flex;\r\n    gap: 16px;\r\n}\r\n\r\n.step-icon {\r\n    width: 32px;\r\n    height: 32px;\r\n    background: rgba(6, 182, 212, 0.1);\r\n    color: var(--accent);\r\n    border-radius: 50%;\r\n    display: flex;\r\n    align-items: center;\r\n    justify-content: center;\r\n    font-weight: 700;\r\n    flex-shrink: 0;\r\n}\r\n\r\n.step-info {\r\n    display: flex;\r\n    flex-direction: column;\r\n    gap: 4px;\r\n}\r\n\r\n.step-title {\r\n    font-size: 14px;\r\n    font-weight: 600;\r\n}\r\n\r\n.step-desc {\r\n    font-size: 13px;\r\n    color: var(--text-muted);\r\n    line-height: 1.4;\r\n}\r\n\r\n.step-desc code {\r\n    background: #222;\r\n    padding: 2px 4px;\r\n    border-radius: 4px;\r\n    font-family: monospace;\r\n    color: var(--accent);\r\n}\r\n\r\n/* Form Styles */\r\n.form-group {\r\n    display: flex;\r\n    flex-direction: column;\r\n    gap: 8px;\r\n    margin-bottom: 16px;\r\n}\r\n\r\n.form-group label {\r\n    font-size: 13px;\r\n    font-weight: 500;\r\n    color: var(--text-muted);\r\n}\r\n\r\n.form-group input {\r\n    background: var(--card-bg);\r\n    border: 1px solid var(--border);\r\n    border-radius: var(--radius-sm);\r\n    padding: 12px;\r\n    color: var(--text);\r\n    font-size: 14px;\r\n    outline: none;\r\n    transition: border-color 0.2s;\r\n}\r\n\r\n.form-group input:focus {\r\n    border-color: var(--accent);\r\n}\r\n\r\n.btn-save {\r\n    background: var(--accent);\r\n    color: #000;\r\n    border: none;\r\n    border-radius: var(--radius-sm);\r\n    padding: 14px;\r\n    font-size: 14px;\r\n    font-weight: 700;\r\n    cursor: pointer;\r\n    transition: transform 0.1s, opacity 0.2s;\r\n    margin-top: 8px;\r\n}\r\n\r\n.btn-save:hover {\r\n    opacity: 0.9;\r\n}\r\n\r\n.btn-save:active {\r\n    transform: scale(0.98);\r\n}\r\n\r\n/* Footer */\r\n.footer {\r\n    padding: 20px;\r\n    text-align: center;\r\n    border-top: 1px solid var(--border);\r\n    display: flex;\r\n    flex-direction: column;\r\n    gap: 4px;\r\n}\r\n\r\n.footer-brand {\r\n    font-size: 12px;\r\n    font-weight: 600;\r\n}\r\n\r\n.footer-tagline {\r\n    font-size: 11px;\r\n    color: var(--text-muted);\r\n    font-style: italic;\r\n}\r\n\r\n/* Scrollbar */\r\n::-webkit-scrollbar {\r\n    width: 6px;\r\n}\r\n\r\n::-webkit-scrollbar-track {\r\n    background: var(--bg);\r\n}\r\n\r\n::-webkit-scrollbar-thumb {\r\n    background: var(--border);\r\n    border-radius: 3px;\r\n}\r\n\r\n::-webkit-scrollbar-thumb:hover {\r\n    background: var(--text-muted);\r\n}";
const HOST_ID = "heisenberg-panel-root";
function init() {
  if (document.getElementById(HOST_ID)) return;
  const host = document.createElement("div");
  host.id = HOST_ID;
  host.style.position = "fixed";
  host.style.top = "0";
  host.style.right = "0";
  host.style.zIndex = "9999999";
  if (document.body && document.contains(document.body)) {
    document.body.appendChild(host);
  }
  const shadow = host.attachShadow({ mode: "open" });
  const styleParams = [panelStyles, appStyles];
  styleParams.forEach((cssContent) => {
    const style = document.createElement("style");
    style.textContent = cssContent;
    shadow.appendChild(style);
  });
  const rootEl = document.createElement("div");
  rootEl.id = "h-root";
  shadow.appendChild(rootEl);
  const root = client.createRoot(rootEl);
  root.render(
    /* @__PURE__ */ jsxRuntimeExports.jsx(React.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SidePanel, {}) })
  );
  console.log("[Heisenberg.ai] Side panel injected");
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}
const locationObserver = new MutationObserver(() => {
  if (!document.getElementById(HOST_ID)) {
    init();
  }
});
locationObserver.observe(document.body, { childList: true, subtree: true });
//# sourceMappingURL=main_panel.jsx.js.map
