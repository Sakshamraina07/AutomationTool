async function getProfile() {
  const result = await chrome.storage.local.get(["userProfile"]);
  return result.userProfile || {};
}
const DAILY_LIMIT = 10;
const BATCH_SIZE = 3;
const COOLDOWN_MS = 20 * 60 * 1e3;
let isOpeningJob = false;
let sessionState = {
  isActive: false,
  isPaused: false,
  queue: [],
  currentIndex: 0,
  tabId: null,
  dailyCount: 0,
  batchCount: 0
};
chrome.runtime.onStartup.addListener(recoverSession);
chrome.runtime.onInstalled.addListener(recoverSession);
async function recoverSession() {
  const { sessionState: saved } = await chrome.storage.local.get(["sessionState"]);
  if (saved == null ? void 0 : saved.isActive) {
    console.log("[InternHelper-BG] Recovering previous session...");
    sessionState = saved;
    openNextJob();
  }
}
async function saveSessionState() {
  await chrome.storage.local.set({ sessionState });
}
async function loadQueue() {
  const { jobQueue } = await chrome.storage.local.get(["jobQueue"]);
  return Array.isArray(jobQueue) ? jobQueue : [];
}
async function saveQueue(queue) {
  await chrome.storage.local.set({ jobQueue: queue });
}
async function loadDailyStats() {
  const today = (/* @__PURE__ */ new Date()).toDateString();
  const { dailyStats } = await chrome.storage.local.get(["dailyStats"]);
  if (!dailyStats || dailyStats.date !== today) {
    return { date: today, count: 0 };
  }
  return dailyStats;
}
async function updateDailyStats() {
  const stats = await loadDailyStats();
  stats.count += 1;
  await chrome.storage.local.set({ dailyStats: stats });
  sessionState.dailyCount = stats.count;
}
function buildViewUrl(job) {
  var _a;
  if (job.jobId) {
    return `https://www.linkedin.com/jobs/view/${job.jobId}/`;
  }
  if ((_a = job.jobUrl) == null ? void 0 : _a.includes("/jobs/view/")) {
    return job.jobUrl.split("?")[0];
  }
  return job.jobUrl;
}
async function openNextJob() {
  if (isOpeningJob) return;
  isOpeningJob = true;
  try {
    if (!sessionState.isActive || sessionState.isPaused) return;
    if (sessionState.dailyCount >= DAILY_LIMIT) {
      await endSession("DAILY_LIMIT");
      return;
    }
    if (sessionState.currentIndex >= sessionState.queue.length) {
      await endSession();
      return;
    }
    const job = sessionState.queue[sessionState.currentIndex];
    if (!job || job.status === "DONE" || job.status === "FAILED") {
      sessionState.currentIndex++;
      await saveSessionState();
      setTimeout(openNextJob, 1e3);
      return;
    }
    job.status = "APPLYING";
    await saveSessionState();
    const queue = await loadQueue();
    const idx = queue.findIndex((j) => j.jobId === job.jobId);
    if (idx !== -1) {
      queue[idx].status = "APPLYING";
      await saveQueue(queue);
    }
    const viewUrl = buildViewUrl(job);
    const tabId = await getActiveTabId();
    if (!tabId) {
      await endSession("NO_ACTIVE_TAB");
      return;
    }
    sessionState.tabId = tabId;
    await saveSessionState();
    chrome.tabs.update(tabId, { url: viewUrl });
    const onTabUpdated = (updatedTabId, changeInfo) => {
      if (updatedTabId !== tabId || changeInfo.status !== "complete") return;
      chrome.tabs.onUpdated.removeListener(onTabUpdated);
      setTimeout(() => {
        getProfile().then((profile) => {
          chrome.tabs.sendMessage(
            tabId,
            { type: "START_AUTOFILL", profile: profile || {} },
            () => {
              void chrome.runtime.lastError;
            }
          );
        });
      }, 5e3);
    };
    chrome.tabs.onUpdated.addListener(onTabUpdated);
  } catch (err) {
    console.error("[InternHelper-BG] openNextJob error:", err);
  } finally {
    isOpeningJob = false;
  }
}
function getActiveTabId() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0]) {
        resolve(tabs[0].id);
      } else {
        resolve(null);
      }
    });
  });
}
async function endSession(reason = null) {
  sessionState.isActive = false;
  await saveSessionState();
  chrome.runtime.sendMessage({ type: "SESSION_COMPLETE", reason }, () => {
    void chrome.runtime.lastError;
  });
}
async function handleAddToQueue(job) {
  if (!(job == null ? void 0 : job.jobId)) {
    return { success: false, error: "INVALID_JOB" };
  }
  const queue = await loadQueue();
  if (queue.some((j) => j.jobId === job.jobId)) {
    return { success: false, error: "DUPLICATE" };
  }
  queue.push({
    ...job,
    status: "PENDING",
    addedAt: Date.now()
  });
  await saveQueue(queue);
  return { success: true };
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case "TRIGGER_AUTOFILL":
      getProfile().then((profile) => {
        var _a;
        if ((_a = sender.tab) == null ? void 0 : _a.id) {
          chrome.tabs.sendMessage(sender.tab.id, {
            type: "START_AUTOFILL",
            profile: profile || {}
          });
          console.log("[InternHelper-BG] Sent START_AUTOFILL to tab", sender.tab.id);
        }
      });
      return true;
    case "GET_FIELD_VALUE":
      (async () => {
        try {
          const profile = message.profile || await getProfile() || {};
          const label = ((message.labelText || "") + " " + (message.placeholder || "")).toLowerCase();
          const type = (message.inputType || "text").toLowerCase();
          let value = null;
          if (type === "tel" || label.includes("phone") || label.includes("mobile")) value = profile.phone || "";
          else if (type === "email" || label.includes("email")) value = profile.email || "";
          else if (label.includes("name")) value = profile.full_name || "";
          sendResponse(value ? { value, source: "profile" } : { value: null, source: "profile" });
        } catch (e) {
          console.warn("[InternHelper-BG] GET_FIELD_VALUE error:", e);
          sendResponse({ value: null, source: "error" });
        }
      })();
      return true;
    case "SAVE_CUSTOM_ANSWER":
      sendResponse({ success: true });
      return true;
    case "CHECK_BACKEND":
      sendResponse({ success: true });
      return true;
    case "GET_SESSION_STATUS":
      sendResponse(sessionState);
      return true;
    case "ADD_TO_QUEUE":
      handleAddToQueue(message.job).then(sendResponse);
      return true;
    case "START_SESSION":
      (async () => {
        const stats = await loadDailyStats();
        if (stats.count >= DAILY_LIMIT) {
          sendResponse({ success: false, error: "DAILY_LIMIT" });
          return;
        }
        const queue = await loadQueue();
        sessionState.queue = queue.filter((j) => j.status !== "DONE");
        sessionState.currentIndex = 0;
        sessionState.isActive = true;
        sessionState.isPaused = false;
        sessionState.batchCount = 0;
        sessionState.dailyCount = stats.count;
        await saveSessionState();
        openNextJob();
        sendResponse({ success: true });
      })();
      return true;
    case "APPLICATION_DONE":
    case "APPLICATION_FAILED":
      (async () => {
        const success = message.type === "APPLICATION_DONE";
        const job = sessionState.queue[sessionState.currentIndex];
        if (job) {
          job.status = success ? "DONE" : "FAILED";
          const queue = await loadQueue();
          const idx = queue.findIndex((j) => j.jobId === job.jobId);
          if (idx !== -1) {
            queue[idx].status = job.status;
            await saveQueue(queue);
          }
        }
        if (success) {
          await updateDailyStats();
          sessionState.batchCount++;
        }
        sessionState.currentIndex++;
        await saveSessionState();
        if (sessionState.batchCount >= BATCH_SIZE) {
          sessionState.isPaused = true;
          setTimeout(async () => {
            sessionState.isPaused = false;
            sessionState.batchCount = 0;
            await saveSessionState();
            openNextJob();
          }, COOLDOWN_MS);
        } else {
          setTimeout(openNextJob, 3e3);
        }
        sendResponse({ success: true });
      })();
      return true;
    case "STOP_SESSION":
      sessionState = {
        isActive: false,
        isPaused: false,
        queue: [],
        currentIndex: 0,
        tabId: null,
        dailyCount: 0,
        batchCount: 0
      };
      saveSessionState();
      sendResponse({ success: true });
      return true;
    case "FILL_EASY_APPLY_FRAME":
      (async () => {
        var _a;
        const tabId = (_a = sender.tab) == null ? void 0 : _a.id;
        if (!tabId) {
          sendResponse({ success: false, error: "NO_TAB" });
          return;
        }
        const profile = message.profile && Object.keys(message.profile).length ? message.profile : await getProfile();
        let targetFrame = null;
        for (let attempt = 0; attempt < 8; attempt++) {
          await new Promise((r) => setTimeout(r, 1e3));
          const frames = await new Promise(
            (r) => chrome.webNavigation.getAllFrames({ tabId }, r)
          );
          (frames || []).forEach((f) => {
            if (f.frameId !== 0) console.log(`[InternHelper-BG] Frame ${f.frameId}: ${f.url}`);
          });
          targetFrame = (frames || []).find(
            (f) => f.frameId !== 0 && !f.url.includes("/preload") && (f.url.includes("/easy-apply") || f.url.includes("/apply/"))
          );
          if (targetFrame) break;
          console.log(`[InternHelper-BG] Frame scan attempt ${attempt + 1}/8 — Easy Apply frame not found yet`);
        }
        if (!targetFrame) {
          console.warn("[InternHelper-BG] Easy Apply iframe not found after 6s.");
          sendResponse({ success: false, error: "FRAME_NOT_FOUND" });
          return;
        }
        console.log("[InternHelper-BG] Found Easy Apply frame:", targetFrame.url, "frameId:", targetFrame.frameId);
        try {
          await chrome.scripting.executeScript({
            target: { tabId, frameIds: [targetFrame.frameId] },
            func: fillFormInFrame,
            args: [profile]
          });
          console.log("[InternHelper-BG] fillFormInFrame injected successfully.");
          sendResponse({ success: true });
        } catch (err) {
          console.error("[InternHelper-BG] executeScript failed:", err);
          sendResponse({ success: false, error: err.message });
        }
      })();
      return true;
  }
});
function fillFormInFrame(profile) {
  console.log("[InternHelper-FRAME] fillFormInFrame running in frame:", window.location.href);
  const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
  const nativeTextareaSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value").set;
  function triggerReact(el, value, isTextarea = false) {
    const setter = isTextarea ? nativeTextareaSetter : nativeSetter;
    setter.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new Event("blur", { bubbles: true }));
  }
  function getLabelText(el) {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    return (((_b = (_a = el.labels) == null ? void 0 : _a[0]) == null ? void 0 : _b.innerText) || el.getAttribute("aria-label") || ((_d = (_c = el.closest("fieldset")) == null ? void 0 : _c.querySelector("legend")) == null ? void 0 : _d.innerText) || ((_f = (_e = el.closest('[class*="form"]')) == null ? void 0 : _e.querySelector("label")) == null ? void 0 : _f.innerText) || ((_h = (_g = el.closest("div")) == null ? void 0 : _g.querySelector("label")) == null ? void 0 : _h.innerText) || "").toLowerCase().trim();
  }
  function mapFieldValue(el, profile2) {
    var _a;
    const label = getLabelText(el);
    const type = (_a = el.type) == null ? void 0 : _a.toLowerCase();
    const ph = (el.placeholder || "").toLowerCase();
    const full = (profile2.full_name || "").trim();
    const parts = full ? full.split(/\s+/) : [];
    const first = parts[0] || "";
    const last = parts.slice(1).join(" ") || "";
    if (type === "tel" || label.includes("phone") || label.includes("mobile") || ph.includes("phone"))
      return profile2.phone || "";
    if (label.includes("first name") || ph.includes("first name"))
      return first;
    if (label.includes("last name") || ph.includes("last name"))
      return last;
    if (label.includes("email") || type === "email")
      return profile2.email || "";
    if (label.includes("name") || ph.includes("name"))
      return full || first || last || "";
    return null;
  }
  const allInputs = [...document.querySelectorAll("input:not([type='hidden']), textarea, select")].filter((el) => !el.disabled && el.offsetParent !== null);
  console.log("[InternHelper-FRAME] Visible inputs in frame:", allInputs.length);
  allInputs.forEach((el) => console.log("[InternHelper-FRAME] Input:", el.type, el.name, el.id, el.placeholder));
  let filled = 0;
  for (const el of allInputs) {
    const tag = el.tagName.toLowerCase();
    const type = (el.type || "").toLowerCase();
    if (type === "radio" || type === "checkbox") continue;
    if (tag === "select") {
      if (el.value && el.value.toLowerCase() !== "select") continue;
      const mapped2 = mapFieldValue(el, profile);
      if (mapped2) {
        const opt = [...el.options].find((o) => o.text.toLowerCase().includes(mapped2.toLowerCase()));
        if (opt) {
          el.value = opt.value;
          el.dispatchEvent(new Event("change", { bubbles: true }));
          filled++;
        }
      }
      continue;
    }
    if (tag === "textarea") {
      if (el.value && el.value.trim() !== "") continue;
      const mapped2 = mapFieldValue(el, profile);
      if (mapped2) {
        triggerReact(el, mapped2, true);
        filled++;
      }
      continue;
    }
    if (el.value && el.value.trim() !== "") continue;
    const mapped = mapFieldValue(el, profile);
    if (mapped !== null && mapped !== "") {
      triggerReact(el, mapped);
      el.dataset.ihFrameFilled = "true";
      filled++;
      console.log("[InternHelper-FRAME] Filled:", getLabelText(el), "→", mapped);
    }
  }
  console.log("[InternHelper-FRAME] Fields filled:", filled);
  setTimeout(() => {
    const btn = [...document.querySelectorAll("button")].find((b) => {
      if (b.disabled || b.offsetParent === null) return false;
      const txt = (b.innerText || "").toLowerCase();
      const aria = (b.getAttribute("aria-label") || "").toLowerCase();
      return txt.includes("next") || txt.includes("review") || txt.includes("submit") || aria.includes("next") || aria.includes("review") || aria.includes("submit");
    });
    if (btn) {
      console.log("[InternHelper-FRAME] Clicking:", btn.innerText.trim());
      btn.click();
    } else {
      console.log("[InternHelper-FRAME] No Next/Review/Submit button found yet.");
    }
  }, 800);
}
//# sourceMappingURL=background.js.js.map
