(function(){const IS_IFRAME = window.self !== window.top;
if (IS_IFRAME) {
  console.log("[InternHelper] Running inside iframe context");
  console.log("[InternHelper] URL:", window.location.href);
}
console.log("[InternHelper] Reactive Event-Driven Engine Loaded");
class AutomationController {
  constructor(profile) {
    this.profile = profile || {};
    this.isActive = true;
    this.stepCount = 0;
    this.idleCycles = 0;
    this.maxIterations = 40;
    this.originalUrl = location.href.split("?")[0];
    this.lastEasyApplyClickTime = 0;
    this.modalWaitWindow = 0;
    this.easyApplyLocked = false;
    this.TEST_MODE = false;
    this.globalLastApplyTime = 0;
    this.applyAttemptsCount = 0;
  }
  async start() {
    console.log("[InternHelper] Starting RTRVR Execution Engine...");
    setInterval(() => {
      console.log("[Tick] Loop running");
    }, 1e3);
    while (this.isActive && this.stepCount < this.maxIterations) {
      this.stepCount++;
      const currentUrl = location.href.split("?")[0];
      if (currentUrl !== this.originalUrl) {
        this.stepCount = 0;
        this.idleCycles = 0;
        this.originalUrl = currentUrl;
        this.lastEasyApplyClickTime = 0;
      }
      const actionTaken = await this.evaluateAndExecute();
      if (!actionTaken) {
        this.idleCycles++;
        if (this.idleCycles >= 6) {
          console.log("[InternHelper] Idle for 6 cycles. Stopping execution.");
          this.isActive = false;
          break;
        }
      } else {
        this.idleCycles = 0;
      }
      await this.randomDelay(800, 1e3);
    }
    window.__INTERN_HELPER_ENGINE = null;
  }
  async humanSleep(min = 1500, max = 3500) {
    const delay = Math.floor(Math.random() * (max - min) + min);
    return new Promise((resolve) => setTimeout(resolve, delay));
  }
  async randomDelay(min = 1500, max = 3500) {
    return this.humanSleep(min, max);
  }
  async performHumanScroll(element) {
    element.scrollIntoView({ behavior: "smooth", block: "center" });
    await this.humanSleep(300, 700);
    window.scrollBy(0, Math.floor(100 + Math.random() * 200));
    await this.humanSleep(500, 1e3);
  }
  // 8. Click Execution Model
  async executeClick(element) {
    await this.performHumanScroll(element);
    element.click();
    await this.humanSleep(1500, 3e3);
  }
  isVisible(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return false;
    const style = window.getComputedStyle(el);
    if (style.visibility === "hidden" || style.opacity === "0" || style.display === "none") return false;
    if (el.disabled || el.getAttribute("aria-disabled") === "true") return false;
    return true;
  }
  async evaluateAndExecute() {
    var _a, _b;
    try {
      const allBtns = Array.from(document.querySelectorAll("button, a"));
      const submitBtn = allBtns.find((b) => {
        var _a2;
        return this.isVisible(b) && (b.innerText.toLowerCase().includes("submit application") || b.innerText.toLowerCase() === "submit" || ((_a2 = b.getAttribute("aria-label")) == null ? void 0 : _a2.toLowerCase().includes("submit app")));
      });
      if (submitBtn) {
        this.isActive = false;
        return true;
      }
      if (!this.PARENT_MODE) {
        const rawInputs = [...document.querySelectorAll("input:not([type='hidden']), textarea, select")];
        const allVisibleInputs = rawInputs.filter((el) => !el.disabled && el.offsetParent !== null);
        if (allVisibleInputs.length > 0) {
          allVisibleInputs.forEach((i) => {
            var _a2;
            console.log("Detected input:", {
              type: i.type,
              name: i.name,
              id: i.id,
              placeholder: i.placeholder,
              value: i.value,
              required: i.required,
              ariaInvalid: i.getAttribute("aria-invalid"),
              validity: (_a2 = i.validity) == null ? void 0 : _a2.valid
            });
          });
          const telInput = allVisibleInputs.find(
            (i) => {
              var _a2, _b2;
              return i.type === "tel" || ((_a2 = i.name) == null ? void 0 : _a2.toLowerCase().includes("phone")) || ((_b2 = i.placeholder) == null ? void 0 : _b2.toLowerCase().includes("phone"));
            }
          );
          if (telInput && (!telInput.value || telInput.value.trim() === "")) {
            const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
            const phoneVal = this.profile.phone_number || this.profile.phone || this.generateFallback({ type: "tel" });
            nativeSetter.call(telInput, phoneVal);
            telInput.dispatchEvent(new Event("input", { bubbles: true }));
            telInput.dispatchEvent(new Event("change", { bubbles: true }));
            telInput.dataset.ihFilled = "true";
            console.log("After fill:", { value: telInput.value, validity: (_a = telInput.validity) == null ? void 0 : _a.valid, ariaInvalid: telInput.getAttribute("aria-invalid") });
            if (!((_b = telInput.validity) == null ? void 0 : _b.valid)) telInput.dispatchEvent(new Event("blur", { bubbles: true }));
            console.log("Filled mobile field");
            return true;
          }
          const getEmptyInputs = () => allVisibleInputs.filter((el) => {
            if (el.type === "radio" || el.type === "checkbox") {
              const group = Array.from((el.ownerDocument || document).querySelectorAll(`input[name="${el.name}"]`));
              return !group.some((r) => r.checked);
            }
            return !el.value || el.value.trim() === "" || el.value.toLowerCase() === "select";
          });
          let emptyInputs = getEmptyInputs();
          const actionableInputs = emptyInputs.filter((el) => !el.dataset.ihFilled);
          if (actionableInputs.length > 0) {
            await this.fillFieldsByInputs(actionableInputs);
            return true;
          }
          emptyInputs = getEmptyInputs();
          if (emptyInputs.length > 0) {
            const stuckInputs = emptyInputs.filter((el) => !el.dataset.ihRetry);
            if (stuckInputs.length > 0) {
              stuckInputs.forEach((el) => {
                delete el.dataset.ihFilled;
                el.dataset.ihRetry = "true";
              });
              return true;
            }
            console.log("[InternHelper] Remaining empty fields, allowing Next.");
          }
          const nextBtn = [...document.querySelectorAll("button")].find((btn) => {
            if (!this.isVisible(btn)) return false;
            const text = (btn.innerText || "").toLowerCase();
            const aria = (btn.getAttribute("aria-label") || "").toLowerCase();
            return (text.includes("next") || aria.includes("next")) && btn.offsetParent !== null;
          });
          if (nextBtn) {
            if (this.TEST_MODE) {
              this.isActive = false;
              return true;
            }
            await this.executeClick(nextBtn);
            return true;
          }
          return true;
        }
      }
      if (!this.IFRAME_MODE) {
        const easyApplyCandidates = allBtns.filter((b) => (b.innerText || "").toLowerCase().includes("easy apply"));
        const visibleEasyApplies = easyApplyCandidates.filter((b) => this.isVisible(b));
        if (visibleEasyApplies.length > 0) {
          const now = Date.now();
          if (this.applyAttemptsCount >= 2 && now - this.globalLastApplyTime < 6e5) {
            console.log("[InternHelper] Rate limit exceeded. Stopping.");
            this.isActive = false;
            return true;
          }
          if (now - this.globalLastApplyTime < 18e4) return true;
          if (now - this.lastEasyApplyClickTime < 3500) return true;
          const easyApplyBtn = visibleEasyApplies[0];
          await this.executeClick(easyApplyBtn);
          this.lastEasyApplyClickTime = Date.now();
          this.globalLastApplyTime = Date.now();
          this.applyAttemptsCount++;
          return true;
        }
        return false;
      }
      return false;
    } catch (e) {
      console.error("[InternHelper] Engine Crash in evaluateAndExecute:", e);
      return false;
    }
  }
  normalizeText(text) {
    if (!text) return "";
    let clean = text.toLowerCase().replace(/[^\w\s]/gi, "").trim();
    const stopwords = ["how", "many", "do", "you", "have", "with", "in", "of", "for", "the", "a", "an", "is", "are", "what", "please", "indicate", "select"];
    clean = clean.split(/\s+/).filter((w) => !stopwords.includes(w)).join(" ");
    return clean;
  }
  calculateFuzzyScore(questionTokens, patternTokens) {
    let matches = 0;
    for (const pt of patternTokens) {
      if (questionTokens.includes(pt)) matches++;
    }
    return patternTokens.length > 0 ? matches / patternTokens.length : 0;
  }
  matchDatabaseAnswer(normalizedQ) {
    const qTokens = normalizedQ.split(/\s+/);
    const patterns = [
      { key: "first_name", words: ["first", "name"] },
      { key: "last_name", words: ["last", "name"] },
      { key: "city", words: ["city"] },
      { key: "city", words: ["location"] },
      { key: "phone", words: ["phone"] },
      { key: "phone", words: ["mobile"] },
      { key: "phone", words: ["number"] },
      { key: "phone", words: ["contact"] },
      { key: "email", words: ["email"] },
      { key: "linkedin_url", words: ["linkedin"] },
      { key: "portfolio_url", words: ["portfolio"] },
      { key: "portfolio_url", words: ["website"] },
      { key: "expected_stipend", words: ["salary"] },
      { key: "expected_stipend", words: ["stipend"] },
      { key: "expected_stipend", words: ["compensation"] },
      { key: "experience", words: ["experience"] },
      { key: "experience", words: ["years"] },
      { key: "notice_period", words: ["notice"] },
      { key: "available_from", words: ["start"] }
    ];
    let bestMatch = null;
    let highestScore = 0;
    for (const pat of patterns) {
      const score = this.calculateFuzzyScore(qTokens, pat.words);
      if (score > highestScore) {
        highestScore = score;
        bestMatch = pat.key;
      }
    }
    if (highestScore >= 0.3) {
      let val = this.profile[bestMatch];
      if (bestMatch === "first_name" && !val && this.profile.full_name) val = this.profile.full_name.split(" ")[0];
      if (bestMatch === "last_name" && !val && this.profile.full_name) val = this.profile.full_name.split(" ").slice(1).join(" ");
      return val;
    }
    return null;
  }
  extractNumberRequired(rawText) {
    const match = rawText.match(/\d+/);
    return match ? parseInt(match[0], 10) : 0;
  }
  // 6. Intelligent Fallback Rules
  generateFallback(ctx) {
    var _a, _b;
    const { element, type, normalizedQuestion } = ctx;
    const isTel = type === "tel" || (element.name || "").toLowerCase().includes("phone");
    if (isTel) {
      const random9 = Math.floor(1e8 + Math.random() * 9e8).toString();
      return "9" + random9;
    }
    if (type === "number") {
      if (normalizedQuestion.includes("years") || normalizedQuestion.includes("experience")) {
        return parseInt(this.profile.experience_years || this.profile.experience || "0", 10);
      }
      if (normalizedQuestion.includes("salary") || normalizedQuestion.includes("stipend")) {
        return parseInt(this.profile.expected_stipend || "0", 10);
      }
      return 0;
    }
    if (type === "email" || (element.name || "").toLowerCase().includes("email")) {
      const first = (this.profile.first_name || ((_a = this.profile.full_name) == null ? void 0 : _a.split(" ")[0]) || "candidate").toLowerCase();
      const last = (this.profile.last_name || ((_b = this.profile.full_name) == null ? void 0 : _b.split(" ")[1]) || "test").toLowerCase();
      return `${first}.${last}@gmail.com`;
    }
    if (element.tagName.toLowerCase() === "textarea") {
      return "I am highly motivated and believe my skills align well with the requirements of this role.";
    }
    return "NA";
  }
  async fillFieldsByInputs(inputs) {
    for (const input of inputs) {
      if (input.dataset.ihFilled) continue;
      let rawQuestion = "";
      if (input.labels && input.labels.length > 0) {
        rawQuestion = input.labels[0].innerText || "";
      } else {
        const container = input.closest(".jobs-easy-apply-form-section, .jobs-easy-apply-form-element, fieldset, div, form");
        const rawLabelNode = container ? container.querySelector("label, legend, span.t-14, strong") : null;
        rawQuestion = rawLabelNode ? rawLabelNode.innerText : input.getAttribute("aria-label") || input.placeholder || "";
      }
      const normalized = this.normalizeText(rawQuestion);
      if (!normalized) {
        input.dataset.ihFilled = "true";
        continue;
      }
      const ctx = {
        element: input,
        type: input.type || input.tagName.toLowerCase(),
        required: input.required || input.getAttribute("aria-required") === "true" || rawQuestion.includes("*"),
        questionText: rawQuestion,
        normalizedQuestion: normalized
      };
      let targetValue = this.matchDatabaseAnswer(normalized);
      if (normalized.includes("experience") || normalized.includes("years")) {
        const requiredYears = this.extractNumberRequired(rawQuestion);
        const myExp = parseInt(this.profile.experience_years || this.profile.experience || "0", 10);
        if (requiredYears > myExp && targetValue !== null) {
          targetValue = myExp;
        }
      }
      if (targetValue === null) {
        targetValue = this.generateFallback(ctx);
      }
      if (input.type === "radio") {
        const doc = input.ownerDocument || document;
        const radioGroup = Array.from(doc.querySelectorAll(`input[name="${input.name}"]`));
        if (radioGroup.length > 0) {
          await this.handleRadios(radioGroup, normalized, targetValue);
          radioGroup.forEach((r) => r.dataset.ihFilled = "true");
        }
      } else if (input.tagName.toLowerCase() === "select" || input.getAttribute("role") === "combobox") {
        await this.handleSelect(input, targetValue);
      } else {
        if (targetValue !== null) {
          await this.humanSleep(1500, 3e3);
          this.setNativeReactValue(input, String(targetValue));
          input.dataset.ihFilled = "true";
        }
      }
    }
  }
  async handleRadios(radioInputs, normalizedQuestion, fuzzyMatchedValue) {
    let clicked = false;
    for (const radio of radioInputs) {
      const id = radio.id;
      const labelEl = radio.parentElement.querySelector(`label[for="${id}"]`) || radio.nextElementSibling || radio.parentElement;
      const rText = ((labelEl == null ? void 0 : labelEl.innerText) || radio.value || "").toLowerCase();
      if (fuzzyMatchedValue !== null && fuzzyMatchedValue !== void 0) {
        if (typeof fuzzyMatchedValue === "boolean") {
          if (fuzzyMatchedValue && rText.includes("yes") || !fuzzyMatchedValue && rText.includes("no")) {
            await this.executeClick(labelEl);
            clicked = true;
            break;
          }
        } else if (rText.includes(String(fuzzyMatchedValue).toLowerCase())) {
          await this.executeClick(labelEl);
          clicked = true;
          break;
        }
      }
    }
    if (!clicked && fuzzyMatchedValue === null) {
      let prefersNo = normalizedQuestion.includes("relocate") || normalizedQuestion.includes("night shift") || normalizedQuestion.includes("bond") || normalizedQuestion.includes("contract");
      for (const radio of radioInputs) {
        const id = radio.id;
        const labelEl = radio.parentElement.querySelector(`label[for="${id}"]`) || radio.nextElementSibling || radio.parentElement;
        const rText = ((labelEl == null ? void 0 : labelEl.innerText) || radio.value || "").toLowerCase();
        if (prefersNo && rText.includes("no")) {
          await this.executeClick(labelEl);
          clicked = true;
          break;
        } else if (!prefersNo && rText.includes("yes")) {
          await this.executeClick(labelEl);
          clicked = true;
          break;
        }
      }
    }
    if (!clicked && radioInputs.length > 0) {
      const id = radioInputs[0].id;
      const backupLabel = radioInputs[0].parentElement.querySelector(`label[for="${id}"]`) || radioInputs[0].parentElement;
      await this.executeClick(backupLabel);
    }
  }
  async handleSelect(selectBtn, targetValue) {
    var _a;
    if (selectBtn.dataset.ihFilled) return;
    if (selectBtn.tagName.toLowerCase() === "select") {
      let valToSet = targetValue;
      if (valToSet == null) {
        const opts = Array.from(selectBtn.options);
        const validOpt = opts.find((o) => o.value && !o.value.toLowerCase().includes("select") && !o.disabled);
        valToSet = validOpt ? validOpt.value : ((_a = opts[1]) == null ? void 0 : _a.value) || "";
      }
      this.setNativeReactValue(selectBtn, valToSet);
      selectBtn.dataset.ihFilled = "true";
    } else {
      await this.executeClick(selectBtn);
      const doc = selectBtn.ownerDocument || document;
      const listbox = doc.querySelector('[role="listbox"]');
      if (listbox) {
        const options = Array.from(listbox.querySelectorAll('li[role="option"], li.artdeco-dropdown__item')).filter((o) => o.getAttribute("aria-disabled") !== "true" && o.offsetParent !== null && !o.innerText.toLowerCase().includes("select"));
        let targetOption = null;
        if (targetValue != null) {
          targetOption = options.find((o) => o.innerText.toLowerCase().includes(String(targetValue).toLowerCase()));
        }
        if (!targetOption && options.length > 0) {
          targetOption = options[0];
        }
        if (targetOption) await this.executeClick(targetOption);
        else await this.executeClick(doc.body);
      }
      selectBtn.dataset.ihFilled = "true";
    }
  }
  setNativeReactValue(element, value) {
    var _a, _b;
    try {
      const valueSetter = (_a = Object.getOwnPropertyDescriptor(element.__proto__, "value")) == null ? void 0 : _a.set;
      const prototypeSetter = (_b = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(element), "value")) == null ? void 0 : _b.set;
      const setter = valueSetter || prototypeSetter;
      if (setter) setter.call(element, value);
      else element.value = value;
      element.dispatchEvent(new Event("input", { bubbles: true }));
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } catch (e) {
    }
  }
}
chrome.storage.local.get(["sessionState", "profile"], (result) => {
  var _a, _b, _c;
  const state = result.sessionState;
  const profile = result.profile || {};
  if (!state || !state.isActive || state.isPaused) return;
  if (IS_IFRAME) {
    const iframeUrl = window.location.href;
    if (!iframeUrl.includes("linkedin.com")) return;
    if (window.__internHelperActive) return;
    window.__internHelperActive = true;
    console.log("[InternHelper] IFRAME ENGINE starting (form fill only)");
    setTimeout(() => {
      if (!window.__INTERN_HELPER_ENGINE) {
        const engine = new AutomationController(profile);
        engine.IFRAME_MODE = true;
        window.__INTERN_HELPER_ENGINE = engine;
        engine.start();
      }
    }, 1500);
    return;
  }
  if (!window.location.href.includes("/jobs/view/")) return;
  if (window.__internHelperActive) return;
  window.__internHelperActive = true;
  const currentUrl = location.href.split("?")[0];
  const targetUrl = (_c = (_b = (_a = state.queue) == null ? void 0 : _a[state.currentIndex]) == null ? void 0 : _b.jobUrl) == null ? void 0 : _c.split("?")[0];
  if (currentUrl === targetUrl) {
    console.log(`[InternHelper] PARENT ENGINE starting (Easy Apply click only).`);
    setTimeout(() => {
      if (!window.__INTERN_HELPER_ENGINE) {
        const engine = new AutomationController(profile);
        engine.PARENT_MODE = true;
        window.__INTERN_HELPER_ENGINE = engine;
        engine.start();
      }
    }, 3e3);
  }
});
//# sourceMappingURL=guided_apply.js.js.map
})()