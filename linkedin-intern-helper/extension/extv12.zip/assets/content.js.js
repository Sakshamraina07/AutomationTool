(function(){console.log("[InternHelper] Content script loaded (Ultra Stable)");
const SELECTORS = {
  DETAILS_CONTAINER: ".jobs-search__job-details--container, .job-view-layout, .jobs-search-two-pane__details",
  ACTIONS_BAR: ".jobs-unified-top-card__actions-container, .jobs-s-apply",
  MODAL: ".jobs-easy-apply-modal",
  MODAL_HEADER: ".artdeco-modal__header",
  BUTTON_ID: "internhelper-queue-btn"
};
const State = {
  detailsObserver: null,
  modalObserver: null,
  lastUrl: location.href
};
function disconnectObservers() {
  var _a, _b;
  (_a = State.detailsObserver) == null ? void 0 : _a.disconnect();
  (_b = State.modalObserver) == null ? void 0 : _b.disconnect();
  State.detailsObserver = null;
  State.modalObserver = null;
}
function injectQueueButton(actionsBar) {
  if (!actionsBar) return;
  if (document.getElementById(SELECTORS.BUTTON_ID)) return;
  const btn = document.createElement("button");
  btn.id = SELECTORS.BUTTON_ID;
  btn.className = "artdeco-button artdeco-button--2 artdeco-button--secondary";
  btn.innerHTML = `<span class="artdeco-button__text">+ Queue</span>`;
  btn.style.cssText = `
        margin-left: 8px;
        background-color: #10b981 !important;
        color: white !important;
        border-color: #10b981 !important;
        min-height: 32px;
    `;
  btn.addEventListener("click", async (e) => {
    e.preventDefault();
    e.stopPropagation();
    await handleAddToQueue(btn);
  });
  if (actionsBar && document.contains(actionsBar)) {
    actionsBar.appendChild(btn);
    console.log("[InternHelper] Queue button injected");
  }
}
async function handleAddToQueue(btn) {
  var _a, _b, _c, _d, _e;
  if (!window.location.href.includes("/jobs/view/") && !window.location.href.includes("/jobs/search/")) return;
  if (btn.dataset.processing) return;
  btn.dataset.processing = "true";
  btn.innerHTML = `<span class="artdeco-button__text">...</span>`;
  const jobId = new URLSearchParams(location.search).get("currentJobId") || ((_a = location.pathname.match(/jobs\/view\/(\d+)/)) == null ? void 0 : _a[1]) || `job_${Date.now()}`;
  const jobUrl = `https://www.linkedin.com/jobs/view/${jobId}/`;
  try {
    const container = document.querySelector(".jobs-search__job-details--container") || document.querySelector(".jobs-details");
    const title = ((_c = (_b = container == null ? void 0 : container.querySelector("h1")) == null ? void 0 : _b.textContent) == null ? void 0 : _c.trim()) || "Job";
    const company = ((_e = (_d = container == null ? void 0 : container.querySelector(".job-details-jobs-unified-top-card__company-name")) == null ? void 0 : _d.textContent) == null ? void 0 : _e.trim()) || "Company";
    const res = await chrome.runtime.sendMessage({
      type: "ADD_TO_QUEUE",
      job: { jobId, jobUrl, title, company, easyApply: true }
    });
    if (res == null ? void 0 : res.success) {
      btn.innerHTML = `<span class="artdeco-button__text">✓</span>`;
    } else if ((res == null ? void 0 : res.error) === "DUPLICATE") {
      btn.innerHTML = `<span class="artdeco-button__text">In Queue</span>`;
    } else {
      btn.innerHTML = `<span class="artdeco-button__text">Limit</span>`;
    }
  } catch (err) {
    console.error(err);
    btn.innerHTML = `<span class="artdeco-button__text">Error</span>`;
  }
  setTimeout(() => {
    if (btn.isConnected) {
      btn.innerHTML = `<span class="artdeco-button__text">+ Queue</span>`;
      delete btn.dataset.processing;
    }
  }, 1500);
}
function setupDetailsObserver(detailsNode) {
  var _a;
  (_a = State.detailsObserver) == null ? void 0 : _a.disconnect();
  const tryInject = () => {
    const actionsBar = detailsNode.querySelector(SELECTORS.ACTIONS_BAR);
    if (actionsBar) injectQueueButton(actionsBar);
  };
  tryInject();
  State.detailsObserver = new MutationObserver(() => {
    if (!document.getElementById(SELECTORS.BUTTON_ID)) {
      tryInject();
    }
  });
  State.detailsObserver.observe(detailsNode, {
    childList: true,
    subtree: false
    // 🔥 PERFORMANCE SAFE
  });
}
function setupModalObserver(modalNode) {
  var _a;
  (_a = State.modalObserver) == null ? void 0 : _a.disconnect();
  const injectSmartApply = () => {
    if (modalNode.querySelector("#ih-smart-apply")) return;
    const header = modalNode.querySelector(SELECTORS.MODAL_HEADER);
    if (!header) return;
    const btn = document.createElement("button");
    btn.id = "ih-smart-apply";
    btn.textContent = "⚡ Smart Apply";
    btn.style.cssText = `
            margin-left:auto;
            margin-right:16px;
            background:#7c3aed;
            color:white;
            border:none;
            padding:4px 12px;
            border-radius:16px;
            font-weight:bold;
            cursor:pointer;
        `;
    if (header && document.contains(header)) {
      header.appendChild(btn);
    }
  };
  injectSmartApply();
  State.modalObserver = new MutationObserver(injectSmartApply);
  State.modalObserver.observe(modalNode, {
    childList: true,
    subtree: false
    // 🔥 PERFORMANCE SAFE
  });
}
function setupGlobalWatcher() {
  const checkNodes = () => {
    const details = document.querySelector(SELECTORS.DETAILS_CONTAINER);
    if (details) setupDetailsObserver(details);
    const modal = document.querySelector(SELECTORS.MODAL);
    if (modal) setupModalObserver(modal);
  };
  checkNodes();
  const bodyObserver = new MutationObserver((mutations) => {
    var _a, _b;
    for (const m of mutations) {
      for (const node of m.addedNodes) {
        if (node.nodeType !== 1) continue;
        if ((_a = node.matches) == null ? void 0 : _a.call(node, SELECTORS.DETAILS_CONTAINER)) {
          setupDetailsObserver(node);
        }
        if ((_b = node.matches) == null ? void 0 : _b.call(node, SELECTORS.MODAL)) {
          setupModalObserver(node);
        }
      }
    }
  });
  bodyObserver.observe(document.body, {
    childList: true,
    subtree: false
    // 🔥 CRITICAL
  });
}
function setupTitleWatcher() {
  const titleEl = document.querySelector("title");
  if (!titleEl) return;
  const observer = new MutationObserver(() => {
    if (location.href !== State.lastUrl) {
      State.lastUrl = location.href;
      console.log("[InternHelper] Navigation detected");
      disconnectObservers();
      setupGlobalWatcher();
    }
  });
  observer.observe(titleEl, { childList: true });
}
function init() {
  setupGlobalWatcher();
  setupTitleWatcher();
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}
//# sourceMappingURL=content.js.js.map
})()