import { g as getProfile, b as base64ToBlob, f as fetchApi, U as USER_ID } from "./profileService-DAR6pnT2.js";
const wait$1 = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const randomDelay = async (min = 1e3, max = 3e3) => {
  const ms = Math.floor(Math.random() * (max - min + 1) + min);
  await wait$1(ms);
};
const BLACKLIST = ["credit", "card", "bank", "ssn", "social security", "account number", "routing", "password", "salary expectations"];
function normalizeLabel(label) {
  if (!label) return "";
  return label.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
}
function isBlacklisted(label) {
  const lowerLabel = label.toLowerCase();
  return BLACKLIST.some((item) => lowerLabel.includes(item));
}
async function getApplicationMemory() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["applicationMemory"], (res) => {
      resolve(res.applicationMemory || { customQuestions: {} });
    });
  });
}
async function saveFieldToMemory(key, value) {
  if (!key || isBlacklisted(key) || value == null) return;
  const memory = await getApplicationMemory();
  if (!memory.customQuestions) {
    memory.customQuestions = {};
  }
  if (memory.customQuestions[key] === value) return;
  memory.customQuestions[key] = value;
  return new Promise((resolve) => {
    chrome.storage.local.set({ applicationMemory: memory }, () => {
      console.log(`[InternHelper] Saved to Memory: ${key} = ${value}`);
      resolve();
    });
  });
}
let timeoutId = null;
function captureInputs(modal) {
  if (!modal) return;
  const inputs = modal.querySelectorAll("input, select, textarea");
  inputs.forEach((input) => {
    if (input.dataset.memoryTracked) return;
    input.dataset.memoryTracked = "true";
    const handler = (e) => handleInputEvent(e.target);
    input.addEventListener("change", handler);
    input.addEventListener("blur", handler);
    input.addEventListener("input", handler);
  });
}
function getLabelText$1(input) {
  let text = "";
  if (input.labels && input.labels.length > 0) {
    text = input.labels[0].textContent;
  } else if (input.getAttribute("aria-label")) {
    text = input.getAttribute("aria-label");
  } else {
    const parent = input.closest("div, label");
    text = parent ? parent.textContent : "";
  }
  return text.replace(/\n/g, " ").replace(/\*/g, "").trim();
}
function getRadioLabelText$1(input) {
  const parent = input.closest("label");
  if (parent) return parent.textContent.trim();
  const nextSibling = input.nextElementSibling;
  if (nextSibling && nextSibling.tagName === "LABEL") return nextSibling.textContent.trim();
  return input.value;
}
function handleInputEvent(target) {
  clearTimeout(timeoutId);
  timeoutId = setTimeout(() => {
    let val = target.value;
    if (target.type === "checkbox") {
      val = target.checked;
    } else if (target.type === "radio") {
      if (!target.checked) return;
      val = getRadioLabelText$1(target);
    }
    let label = "";
    if (target.type === "radio" || target.type === "checkbox") {
      const fieldset = target.closest("fieldset");
      if (fieldset) {
        const legend = fieldset.querySelector("legend, .fb-dash-form-element__label");
        if (legend) label = legend.textContent;
      }
    }
    if (!label) {
      label = getLabelText$1(target);
    }
    const key = normalizeLabel(label);
    if (key && val !== void 0 && val !== "") {
      saveFieldToMemory(key, val);
    }
  }, 500);
}
function observeModalForInputs(modal) {
  if (!modal || modal.dataset.observerAttached) return;
  modal.dataset.observerAttached = "true";
  captureInputs(modal);
  const observer2 = new MutationObserver(() => {
    captureInputs(modal);
  });
  observer2.observe(modal, { childList: true, subtree: true, attributes: false });
}
let isRunning$1 = false;
let observer = null;
async function runAutofill(onStopCallback) {
  if (isRunning$1) return;
  isRunning$1 = true;
  console.log("[InternHelper] Starting Autofill Engine...");
  const { profile, resume } = await getProfile();
  const memory = await getApplicationMemory();
  console.log("[InternHelper] Profile Data & Memory Loaded");
  await processModalSteps({ profile, resume, memory });
}
async function processModalSteps(fullProfile, onStopCallback) {
  const MAX_STEPS = 5;
  let step = 0;
  while (step < MAX_STEPS && isRunning$1) {
    step++;
    console.log(`[InternHelper] Processing Step ${step}...`);
    const modal = await waitForModalStable();
    if (!modal) break;
    observeModalForInputs(modal);
    const submitBtn = findButtonByText("Submit application") || document.querySelector('[aria-label="Submit application"]') || findSubmitButton();
    if (submitBtn) {
      console.log("[InternHelper] Submit Button Found! Waiting for manual submit.");
      highlightSubmitButton(submitBtn);
      cleanup();
      return;
    }
    await fillInputsContinuously(fullProfile, modal);
    const nextBtn = findButtonByText("Next") || findButtonByText("Review");
    if (nextBtn) {
      const hiddenSubmit = document.querySelector('[aria-label="Submit application"]') || findSubmitButton();
      if (hiddenSubmit) {
        console.log("[InternHelper] Hidden Submit Button Found! Waiting for manual submit.");
        highlightSubmitButton(hiddenSubmit);
        cleanup();
        return;
      }
      console.log("[InternHelper] Clicking Next/Review...");
      await randomDelay(1e3, 2e3);
      nextBtn.click();
      await randomDelay(2e3, 3e3);
    } else {
      console.log("[InternHelper] No Next/Submit button found. Stopping.");
      cleanup();
      return;
    }
  }
  cleanup();
}
function fillInputsContinuously(fullProfile, modal) {
  return new Promise(async (resolve) => {
    let hasFilled = false;
    const tryFillAll = async () => {
      const inputs = modal.querySelectorAll("input, select, textarea");
      for (const input of inputs) {
        if (isVisible(input) && !input.value && !input.dataset.ihFilled) {
          await randomDelay(800, 2e3);
          if (isVisible(input) && !input.value) {
            const filled = await tryFillInput(input, fullProfile);
            if (filled) {
              input.dataset.ihFilled = "true";
              hasFilled = true;
            }
          }
        }
      }
    };
    await tryFillAll();
    observer = new MutationObserver(async (mutations) => {
      observer.disconnect();
      await tryFillAll();
      if (modal) {
        observer.observe(modal, { childList: true, subtree: true });
      }
    });
    observer.observe(modal, { childList: true, subtree: true });
    setTimeout(() => {
      if (observer) observer.disconnect();
      resolve(hasFilled);
    }, 4e3);
  });
}
function cleanup() {
  isRunning$1 = false;
  if (observer) {
    observer.disconnect();
    observer = null;
  }
}
async function waitForModalStable() {
  return new Promise((resolve) => {
    let stableFrames = 0;
    let lastModal = null;
    let attempts = 0;
    const interval = setInterval(() => {
      attempts++;
      const modal = document.querySelector('.jobs-easy-apply-modal, [role="dialog"][aria-modal="true"]');
      if (modal) {
        stableFrames++;
        lastModal = modal;
        if (stableFrames > 2) {
          clearInterval(interval);
          resolve(lastModal);
        }
      }
      if (attempts > 30) {
        clearInterval(interval);
        resolve(null);
      }
    }, 500);
  });
}
function findSubmitButton() {
  const buttons = Array.from(document.querySelectorAll("button"));
  return buttons.find((btn) => {
    if (!isVisible(btn)) return false;
    const text = (btn.innerText || "").toLowerCase();
    const ariaLabel = (btn.getAttribute("aria-label") || "").toLowerCase();
    return text.includes("submit application") || ariaLabel.includes("submit application");
  });
}
async function tryFillInput(input, fullProfile) {
  var _a, _b;
  const labelText = getLabelText(input);
  const labelKey = normalizeLabel(labelText);
  const name = (input.name || "").toLowerCase();
  const id = (input.id || "").toLowerCase();
  const type = input.type;
  const { profile, resume, memory } = fullProfile;
  if (type === "file") {
    if ((labelText.toLowerCase().includes("resume") || labelText.toLowerCase().includes("cv")) && resume) {
      try {
        const fileBlob = base64ToBlob(resume.data, resume.type);
        const dt = new DataTransfer();
        dt.items.add(new File([fileBlob], resume.name, { type: resume.type }));
        input.files = dt.files;
        input.dispatchEvent(new Event("change", { bubbles: true }));
        console.log("[InternHelper] Attached Resume:", resume.name);
        return true;
      } catch (e) {
        console.error("[InternHelper] Failed to attach resume", e);
      }
    }
    return false;
  }
  let value = null;
  if (labelKey && (memory == null ? void 0 : memory.customQuestions) && memory.customQuestions[labelKey]) {
    value = memory.customQuestions[labelKey];
    console.log(`[InternHelper] Autofilling from Memory: ${labelKey} = ${value}`);
  }
  if (!value) {
    const profileMap = {
      "first name": profile.firstName || ((_a = profile.full_name) == null ? void 0 : _a.split(" ")[0]),
      "last name": profile.lastName || ((_b = profile.full_name) == null ? void 0 : _b.split(" ").slice(1).join(" ")),
      "full name": profile.full_name,
      "phone": profile.phone,
      "mobile": profile.phone,
      "email": profile.email,
      "city": profile.location,
      "location": profile.location,
      "linkedin": profile.linkedin_url,
      "portfolio": profile.portfolio_url,
      "website": profile.portfolio_url,
      "blog": profile.portfolio_url,
      // Advanced Internship Mappings
      "university": profile.university,
      "school": profile.university,
      "college": profile.university,
      "degree": profile.degree,
      "bachelor": profile.degree,
      "master": profile.degree,
      "major": profile.major,
      "gpa": profile.gpa,
      "grade": profile.gpa,
      "graduation": profile.graduation_year,
      "graduating": profile.graduation_year,
      "student": profile.current_year,
      "year": profile.current_year,
      "authorized": profile.work_authorized ? "Yes" : "No",
      "authorization": profile.work_authorized ? "Yes" : "No",
      "legally": profile.work_authorized ? "Yes" : "No",
      "require sponsorship": profile.work_authorized ? "No" : "Yes",
      "relocate": profile.relocation ? "Yes" : "No",
      "relocation": profile.relocation ? "Yes" : "No",
      "stipend": profile.expected_stipend,
      "compensation": profile.expected_stipend,
      "salary": profile.expected_stipend,
      "notice": profile.notice_period,
      "start date": profile.notice_period,
      "available from": profile.notice_period,
      "skills": profile.skills,
      "experience": profile.experience || profile.experience_summary,
      "years": profile.experience || profile.experience_summary,
      "cover letter": profile.cover_letter
    };
    const checkKeys = [...Object.keys(profileMap)];
    const targetStr = `${labelText} ${name} ${id}`.toLowerCase();
    for (const key of checkKeys) {
      if (targetStr.includes(key) && profileMap[key]) {
        value = profileMap[key];
        console.log(`[InternHelper] keyword match: "${key}" -> injected "${value}" (Label matched: ${labelText})`);
        break;
      }
    }
  }
  if (!value && profile.common_answers && profile.common_answers[labelKey]) {
    value = profile.common_answers[labelKey];
  }
  if (value) {
    if (type === "radio" || type === "checkbox" || input.tagName === "SELECT") {
      if (input.tagName === "SELECT") {
        const option = Array.from(input.options).find(
          (o) => o.text.toLowerCase() === value.toLowerCase() || o.value.toLowerCase() === value.toLowerCase() || o.text.toLowerCase().includes(value.toLowerCase())
        );
        if (option) {
          setNativeValue(input, option.value);
          return true;
        }
      } else if (type === "radio") {
        const radioLabel = getRadioLabelText(input).toLowerCase();
        if (radioLabel.includes(value.toLowerCase()) || value.toLowerCase() === radioLabel) {
          input.click();
          return true;
        }
      } else if (type === "checkbox") {
        if (value === true || value.toString().toLowerCase() === "yes") {
          if (!input.checked) input.click();
          return true;
        }
      }
    } else {
      setNativeValue(input, value);
      return true;
    }
  } else {
    if (input.tagName !== "FILE" && type !== "file") {
      input.style.border = "2px solid #3b82f6";
      input.setAttribute("title", "InternHelper: Please fill this to teach the Intelligent Memory");
    }
  }
  return false;
}
function getLabelText(input) {
  let text = "";
  if (input.type === "radio" || input.type === "checkbox") {
    const fieldset = input.closest("fieldset");
    if (fieldset) {
      const legend = fieldset.querySelector("legend, .fb-dash-form-element__label");
      if (legend) text = legend.textContent;
    }
  }
  if (!text) {
    if (input.labels && input.labels.length > 0) {
      text = input.labels[0].textContent;
    } else if (input.getAttribute("aria-label")) {
      text = input.getAttribute("aria-label");
    } else {
      const parent = input.closest("div, label");
      text = parent ? parent.textContent : "";
    }
  }
  return text.replace(/\n/g, " ").replace(/\*/g, "").trim();
}
function getRadioLabelText(input) {
  const parent = input.closest("label");
  if (parent) return parent.textContent.trim();
  const nextSibling = input.nextElementSibling;
  if (nextSibling && nextSibling.tagName === "LABEL") return nextSibling.textContent.trim();
  return input.value || "";
}
function setNativeValue(element, value) {
  var _a, _b;
  const valueSetter = (_a = Object.getOwnPropertyDescriptor(element.__proto__, "value")) == null ? void 0 : _a.set;
  const prototype = Object.getPrototypeOf(element);
  const prototypeValueSetter = (_b = Object.getOwnPropertyDescriptor(prototype, "value")) == null ? void 0 : _b.set;
  if (valueSetter && valueSetter !== prototypeValueSetter) {
    prototypeValueSetter.call(element, value);
  } else if (valueSetter) {
    valueSetter.call(element, value);
  } else {
    element.value = value;
  }
  element.dispatchEvent(new Event("input", { bubbles: true }));
  element.dispatchEvent(new Event("change", { bubbles: true }));
}
function findButtonByText(text) {
  return Array.from(document.querySelectorAll(".jobs-easy-apply-modal button")).find((b) => {
    var _a;
    return b.textContent.trim() === text || ((_a = b.querySelector("span")) == null ? void 0 : _a.textContent.trim()) === text;
  });
}
function isVisible(elem) {
  return !!(elem.offsetWidth || elem.offsetHeight || elem.getClientRects().length);
}
function highlightSubmitButton(btn) {
  btn.style.border = "4px solid #f5c258";
  btn.style.boxShadow = "0 0 10px #f5c258";
  btn.setAttribute("title", "Review & Click Submit to Continue");
  let tooltip = document.getElementById("intern-helper-tooltip");
  if (!tooltip) {
    tooltip = document.createElement("div");
    tooltip.id = "intern-helper-tooltip";
    tooltip.style.position = "absolute";
    tooltip.style.bottom = "110%";
    tooltip.style.left = "50%";
    tooltip.style.transform = "translateX(-50%)";
    tooltip.style.background = "#f5c258";
    tooltip.style.color = "black";
    tooltip.style.padding = "6px 12px";
    tooltip.style.borderRadius = "4px";
    tooltip.style.fontWeight = "bold";
    tooltip.style.zIndex = "9999";
    tooltip.style.whiteSpace = "nowrap";
    tooltip.style.boxShadow = "0 2px 5px rgba(0,0,0,0.2)";
    btn.parentElement.style.position = "relative";
    btn.parentElement.appendChild(tooltip);
  }
  tooltip.innerText = "Please review your application and Submit manually.";
}
const STATE = {
  OPEN_JOB: "OPEN_JOB",
  CLICK_EASY_APPLY: "CLICK_EASY_APPLY",
  FILL_FORM: "FILL_FORM",
  WAITING_SUBMIT: "WAITING_SUBMIT",
  DONE: "DONE",
  FAILED: "FAILED"
};
let currentState = STATE.OPEN_JOB;
let currentJob = null;
let isRunning = false;
function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function isElementVisible(el) {
  if (!el) return false;
  const style = window.getComputedStyle(el);
  if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0") return false;
  const rect = el.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}
async function startJobStateMachine(job) {
  if (!job) return;
  if (isRunning) {
    console.warn("[InternHelper] State machine already running. Skipping.");
    return;
  }
  if (!window.location.pathname.includes("/jobs/view/")) {
    console.warn("[InternHelper] Not on a job view page. Blocking execution.");
    return;
  }
  isRunning = true;
  currentJob = job;
  currentState = STATE.OPEN_JOB;
  console.log(`[InternHelper] Starting State Machine for: ${job.title}`);
  try {
    await processStateMachine();
  } catch (e) {
    console.error("[InternHelper] State Machine Crash:", e);
    chrome.runtime.sendMessage({
      type: "APPLICATION_FAILED",
      reason: e.message
    });
  } finally {
    isRunning = false;
  }
}
async function processStateMachine() {
  while (currentState !== STATE.DONE && currentState !== STATE.FAILED) {
    console.log(`[InternHelper] Current State: ${currentState}`);
    switch (currentState) {
      case STATE.OPEN_JOB:
        await handleOpenJob();
        break;
      case STATE.CLICK_EASY_APPLY:
        await handleClickEasyApply();
        break;
      case STATE.FILL_FORM:
        await handleFillForm();
        break;
      case STATE.WAITING_SUBMIT:
        await handleWaitingSubmit();
        break;
    }
    await randomDelay(800, 1500);
  }
  if (currentState === STATE.DONE) {
    console.log("[InternHelper] Application Complete.");
    chrome.runtime.sendMessage({ type: "APPLICATION_DONE" });
  } else {
    console.log("[InternHelper] Application Failed.");
    chrome.runtime.sendMessage({ type: "APPLICATION_FAILED" });
  }
}
function findEasyApplyButton() {
  const elements = Array.from(document.querySelectorAll("button, a"));
  for (const el of elements) {
    if (!isElementVisible(el)) continue;
    if (el.disabled || el.hasAttribute("disabled")) {
      continue;
    }
    const text = (el.innerText || "").toLowerCase();
    const ariaLabel = (el.getAttribute("aria-label") || "").toLowerCase();
    const controlName = (el.getAttribute("data-control-name") || "").toLowerCase();
    const className = (el.className || "").toString().toLowerCase();
    const isAlreadyApplied = text.includes("applied") && !text.includes("easy apply");
    if (isAlreadyApplied) continue;
    if (ariaLabel.includes("easy apply")) {
      console.log("[IH] Easy Apply Strategy A success");
      return el;
    }
    if (controlName.includes("jobdetails_topcard_inapply") || controlName.includes("apply")) {
      if (!text.includes("save")) {
        console.log("[IH] Strategy B matched");
        return el;
      }
    }
    if (className.includes("jobs-apply-button") || className.includes("jobs-s-apply")) {
      console.log("[IH] Strategy C matched");
      return el;
    }
    if (text.includes("easy apply")) {
      console.log("[IH] Strategy D matched");
      return el;
    }
  }
  return null;
}
function findModal() {
  const modal = document.querySelector('.jobs-easy-apply-modal, [role="dialog"][aria-modal="true"]');
  if (modal && isElementVisible(modal)) {
    return modal;
  }
  return null;
}
async function waitForJobContainer() {
  console.log("[IH] Waiting for job details container...");
  const maxWait = 1e4;
  const start = Date.now();
  while (Date.now() - start < maxWait) {
    if (document.querySelector(".jobs-search__job-details--container, .job-view-layout")) {
      console.log("[IH] Job details container found.");
      return true;
    }
    await wait(500);
  }
  return false;
}
function waitForButtonMutationObserver(timeout = 8e3) {
  return new Promise((resolve) => {
    const observer2 = new MutationObserver(() => {
      const btn = findEasyApplyButton();
      if (btn) {
        console.log("[IH] Mutation observer detected button");
        observer2.disconnect();
        resolve(btn);
      }
    });
    const container = document.querySelector(".jobs-search__job-details--container, .job-view-layout") || document.body;
    observer2.observe(container, { childList: true, subtree: true, attributes: true });
    setTimeout(() => {
      observer2.disconnect();
      resolve(null);
    }, timeout);
  });
}
async function handleOpenJob() {
  console.log("[InternHelper] Searching for Easy Apply button...");
  const hasContainer = await waitForJobContainer();
  if (!hasContainer) {
    console.warn("[IH] Job details container never appeared. Proceeding anyway...");
  }
  let delay = 500;
  const maxTotalTime = 3e4;
  const start = Date.now();
  while (Date.now() - start < maxTotalTime) {
    console.log(`[IH] Polling for Easy Apply button (delay: ${delay}ms)...`);
    const btn = findEasyApplyButton();
    if (btn) {
      await wait(500);
      const stableBtn = findEasyApplyButton();
      if (stableBtn) {
        console.log("[InternHelper] Easy Apply button is stable and found.");
        currentState = STATE.CLICK_EASY_APPLY;
        return;
      }
    }
    await wait(delay);
    delay = Math.min(delay * 1.5, 3e3);
  }
  console.log("[IH] Polling exhausted. Attaching MutationObserver fallback...");
  const btnFromObserver = await waitForButtonMutationObserver(8e3);
  if (btnFromObserver) {
    await wait(500);
    if (findEasyApplyButton()) {
      console.log("[InternHelper] Easy Apply button stable after mutation observer.");
      currentState = STATE.CLICK_EASY_APPLY;
      return;
    }
  }
  const bodyText = document.body.innerText.toLowerCase();
  if (bodyText.includes("no longer accepting applications")) {
    console.log("[IH] Job is expired (No longer accepting applications).");
    currentState = STATE.FAILED;
    return;
  }
  if (bodyText.includes("applied on") || bodyText.includes("already applied")) {
    console.log("[InternHelper] Job already applied.");
    currentState = STATE.DONE;
    return;
  }
  console.log("[IH] Checking one final time after 5 seconds...");
  await wait(5e3);
  if (findEasyApplyButton()) {
    console.log("[InternHelper] Easy Apply found on final retry.");
    currentState = STATE.CLICK_EASY_APPLY;
    return;
  }
  console.log("[InternHelper] Could not find Easy Apply button after all retries and fallbacks.");
  currentState = STATE.FAILED;
}
async function handleClickEasyApply() {
  const applyBtn = findEasyApplyButton();
  if (!applyBtn) {
    console.log("[InternHelper] Button lost before click. Reverting to OPEN_JOB.");
    currentState = STATE.OPEN_JOB;
    return;
  }
  console.log("[InternHelper] Clicking Easy Apply...");
  try {
    applyBtn.scrollIntoView({ behavior: "smooth", block: "center" });
    await wait(600);
    applyBtn.focus();
    await wait(300);
    applyBtn.click();
    console.log("[InternHelper] Click dispatched. Waiting for modal to open.");
    const MAX_MODAL_WAIT = 20;
    for (let i = 0; i < MAX_MODAL_WAIT; i++) {
      await wait(500);
      if (findModal()) {
        console.log("[InternHelper] Modal successfully opened.");
        currentState = STATE.FILL_FORM;
        return;
      }
    }
    console.log("[InternHelper] Modal did not appear after click. Reverting to OPEN_JOB.");
    currentState = STATE.OPEN_JOB;
  } catch (e) {
    console.error("[InternHelper] Error clicking button:", e);
    currentState = STATE.FAILED;
  }
}
async function handleFillForm() {
  const modal = findModal();
  if (!modal) {
    console.log("[InternHelper] Modal disappeared before filling started. Reverting to OPEN_JOB.");
    currentState = STATE.OPEN_JOB;
    return;
  }
  console.log("[InternHelper] Modal present. Triggering AutofillEngine...");
  try {
    await runAutofill();
    currentState = STATE.WAITING_SUBMIT;
  } catch (e) {
    console.error("[InternHelper] Error running autofill:", e);
    currentState = STATE.FAILED;
  }
}
async function handleWaitingSubmit() {
  console.log("[InternHelper] Waiting for user to submit manually...");
  const MAX_WAIT_TIME = 10 * 60 * 1e3;
  const INTERVAL = 1e3;
  const checks = MAX_WAIT_TIME / INTERVAL;
  for (let i = 0; i < checks; i++) {
    await wait(INTERVAL);
    const modal = findModal();
    if (!modal) {
      await wait(1e3);
      const domText = document.body.innerText.toLowerCase();
      const successTexts = [
        "application was sent",
        "application submitted",
        "applied on",
        "your application was sent"
      ];
      const isSuccess = successTexts.some((text) => domText.includes(text));
      if (isSuccess) {
        console.log("[InternHelper] Application success confirmation detected.");
        currentState = STATE.DONE;
        try {
          await fetchApi("/applications/track", {
            method: "POST",
            body: JSON.stringify({
              user_id: USER_ID,
              job_id: window.location.href,
              // or parse exactly
              title: (currentJob == null ? void 0 : currentJob.title) || document.title.split("|")[0].trim(),
              company: (currentJob == null ? void 0 : currentJob.company) || "Unknown Company",
              status: "APPLIED"
            })
          });
          console.log("[InternHelper] Successfully tracked application to Render DB.");
        } catch (apiErr) {
          console.error("[InternHelper] Failed to push history to Render DB:", apiErr);
        }
      } else {
        console.warn("[InternHelper] Modal closed but no success confirmation found. Marking FAILED.");
        currentState = STATE.FAILED;
      }
      return;
    }
  }
  console.log("[InternHelper] Timeout waiting for manual submit.");
  currentState = STATE.FAILED;
}
console.log("[InternHelper] Guided Apply Script Loaded (Ultra Stable)");
let isApplying = false;
chrome.storage.local.get(["sessionState"], (result) => {
  var _a, _b;
  const state = result.sessionState;
  if (state && state.isActive && !state.isPaused) {
    if (!window.location.href.includes("/jobs/view/")) return;
    if (window.__INTERN_HELPER_LOCK) return;
    window.__INTERN_HELPER_LOCK = true;
    if (isApplying) return;
    const currentJob2 = state.queue[state.currentIndex];
    const currentUrl = location.href.split("?")[0];
    const targetUrl = (_a = currentJob2 == null ? void 0 : currentJob2.jobUrl) == null ? void 0 : _a.split("?")[0];
    if (currentJob2 && currentUrl === targetUrl) {
      isApplying = true;
      console.log(`[InternHelper] Resuming session for: ${currentJob2.title}`);
      setTimeout(() => startJobStateMachine(currentJob2), 3e3);
    } else if ((_b = currentJob2 == null ? void 0 : currentJob2.jobUrl) == null ? void 0 : _b.includes("/jobs/view/")) {
      console.log("[InternHelper] URL mismatch. Background script controls navigation, content script doing nothing.");
    }
  }
});
//# sourceMappingURL=guided_apply.js-DkKrrzq2.js.map
