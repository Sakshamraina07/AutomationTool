import { r as reactExports, j as jsxRuntimeExports } from "./jsx-runtime.js";
(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
function App() {
  const [view, setView] = reactExports.useState("workflow");
  const [profile, setProfile] = reactExports.useState({ full_name: "", email: "", phone: "" });
  const [isComplete, setIsComplete] = reactExports.useState(true);
  const [saveStatus, setSaveStatus] = reactExports.useState("idle");
  reactExports.useEffect(() => {
    chrome.storage.local.get(["userProfile"], (res) => {
      if (res.userProfile) {
        setProfile(res.userProfile);
        checkCompleteness(res.userProfile);
      } else {
        setIsComplete(false);
      }
    });
  }, []);
  const checkCompleteness = (p) => {
    const complete = !!(p.full_name && p.email && p.phone);
    setIsComplete(complete);
  };
  const handleSave = () => {
    setSaveStatus("saving");
    chrome.storage.local.set({ userProfile: profile }, () => {
      setTimeout(() => {
        setSaveStatus("success");
        checkCompleteness(profile);
        setTimeout(() => setSaveStatus("idle"), 2e3);
      }, 400);
    });
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setProfile((prev) => ({ ...prev, [name]: value }));
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "heisenberg-root", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "popup-container", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "header", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { children: "Heisenberg.ai" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "tagline", children: "Precision job applications." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("nav", { className: "tabs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          className: `tab-btn ${view === "workflow" ? "active" : ""}`,
          onClick: () => setView("workflow"),
          children: "Workflow"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          className: `tab-btn ${view === "profile" ? "active" : ""}`,
          onClick: () => setView("profile"),
          children: "Profile"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { className: "main-content", children: [
      !isComplete && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "warning-banner", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "⚠️ Setup your profile to enable auto-apply." }) }),
      view === "workflow" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "workflow-view", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "section-title", children: "Setup Guide" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "workflow-step", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "step-number", children: "1" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "step-info", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "step-title", children: "Load Extension" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "step-desc", children: [
              "In ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("code", { children: "chrome://extensions" }),
              ", enable ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("b", { children: "Developer Mode" }),
              " and load the extracted folder."
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "workflow-step", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "step-number", children: "2" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "step-info", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "step-title", children: "Verify Status" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "step-desc", children: [
              "Ensure the ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("b", { children: "Service Worker" }),
              " is active. Refresh LinkedIn if detection fails."
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "workflow-step", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "step-number", children: "3" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "step-info", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "step-title", children: "Apply Effortlessly" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "step-desc", children: [
              "Open any LinkedIn job with ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("b", { children: "Easy Apply" }),
              ". Heisenberg.ai handles the rest automatically."
            ] })
          ] })
        ] })
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "profile-view", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "section-title", children: "Your Identity" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-group", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "Full Name" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              name: "full_name",
              placeholder: "Walter White",
              value: profile.full_name,
              onChange: handleChange
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-group", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "Email Address" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              name: "email",
              type: "email",
              placeholder: "heisenberg@albuquerque.com",
              value: profile.email,
              onChange: handleChange
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-group", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "Phone Number" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              name: "phone",
              placeholder: "+1 (505) 123-4567",
              value: profile.phone,
              onChange: handleChange
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            className: `btn-save ${saveStatus === "success" ? "success" : ""}`,
            onClick: handleSave,
            disabled: saveStatus === "saving",
            children: saveStatus === "idle" ? "Save Profile" : saveStatus === "saving" ? "Saving..." : "Changes Saved ✓"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("footer", { className: "footer", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "footer-inner", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "footer-brand", children: "Heisenberg.ai v1.1" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "footer-tagline", children: "“Uncertainty eliminated.”" })
    ] }) })
  ] }) });
}
ReactDOM.createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(React.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(App, {}) })
);
//# sourceMappingURL=index.html.js.map
