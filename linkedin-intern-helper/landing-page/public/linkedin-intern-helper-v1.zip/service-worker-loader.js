import './assets/background.js-CMEsAJHa.js';
