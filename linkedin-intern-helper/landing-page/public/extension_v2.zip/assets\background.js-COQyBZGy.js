console.log("[InternHelper] Background Service Worker Loaded");chrome.runtime.onInstalled.addListener(()=>{console.log("InternHelper Extension Installed")});
