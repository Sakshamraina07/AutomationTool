(function(){console.log("[InternHelper] Reactive Event-Driven Engine Loaded");
class AutomationController {
  constructor(profile) {
    this.profile = profile || {};
    this.isActive = true;
    this.stepCount = 0;
    this.idleCycles = 0;
    this.maxIterations = 25;
    this.originalUrl = location.href.split("?")[0];
    this.clickRetries = 0;
  }
  async start() {
    console.log("[InternHelper] Starting Reactive Automation Loop...");
    while (this.isActive && this.stepCount < this.maxIterations) {
      this.stepCount++;
      const currentUrl = location.href.split("?")[0];
      if (currentUrl !== this.originalUrl) {
        console.log("[InternHelper] SPA Route changed mid-execution. Halting Autoloop.");
        this.isActive = false;
        break;
      }
      console.log(`[InternHelper] Cycle ${this.stepCount}...`);
      const actionTaken = await this.evaluateAndExecute();
      if (!actionTaken) {
        this.idleCycles++;
        if (this.idleCycles >= 5) {
          console.log("[InternHelper] No actionable elements for 5 cycles. Stopping.");
          this.isActive = false;
          break;
        }
      } else {
        this.idleCycles = 0;
      }
      await this.randomDelay(700, 1e3);
    }
    if (this.stepCount >= this.maxIterations) {
      console.warn(`[InternHelper] Max iterations (${this.maxIterations}) reached. Stopping.`);
    }
    console.log("[InternHelper] Automation Loop Terminated.");
    window.__INTERN_HELPER_ENGINE = null;
  }
  async randomDelay(min = 400, max = 1200) {
    const delay = Math.floor(Math.random() * (max - min) + min);
    return new Promise((resolve) => setTimeout(resolve, delay));
  }
  isVisible(el) {
    if (!el || el.offsetParent === null) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return false;
    if (el.disabled || el.getAttribute("aria-disabled") === "true") return false;
    return true;
  }
  async evaluateAndExecute() {
    const submitBtn = this.findSubmitButton();
    if (submitBtn) {
      console.log("[InternHelper] Action: Found Submit. Halting automation.");
      submitBtn.style.border = "4px solid #00FF00";
      Object.assign(submitBtn.style, { boxShadow: "0 0 15px #00FF00", transition: "all 0.3s ease" });
      this.isActive = false;
      return true;
    }
    const nextBtn = this.findNextButton();
    if (nextBtn) {
      console.log("[InternHelper] Action: Found Next. Clicking.");
      nextBtn.scrollIntoView({ behavior: "smooth", block: "center" });
      await this.randomDelay(400, 1200);
      nextBtn.click();
      return true;
    }
    const modal = document.querySelector('div[role="dialog"]');
    if (modal && this.isVisible(modal)) {
      const errors = modal.querySelectorAll('[aria-invalid="true"]');
      if (errors.length > 0) {
        console.error("[InternHelper] Action: Validation Error Detected. Halting automation.");
        this.isActive = false;
        return true;
      }
      const containers = Array.from(modal.querySelectorAll(".jobs-easy-apply-form-section, .jobs-easy-apply-form-element, fieldset"));
      const actionableContainers = containers.filter((c) => this.isVisible(c) && !c.dataset.ihProcessed);
      if (actionableContainers.length > 0) {
        console.log(`[InternHelper] Action: Filling ${actionableContainers.length} fields.`);
        await this.randomDelay(400, 1200);
        await this.fillFields(actionableContainers);
        return true;
      }
    }
    if (!modal || !this.isVisible(modal)) {
      const easyApplyBtn = this.findEasyApplyButton();
      if (easyApplyBtn) {
        console.log("[InternHelper] Action: Found Easy Apply. Clicking.");
        easyApplyBtn.scrollIntoView({ behavior: "smooth", block: "center" });
        await this.randomDelay(400, 1200);
        easyApplyBtn.click();
        await this.randomDelay(1e3, 1500);
        const checkModal = document.querySelector('div[role="dialog"]');
        if (!checkModal || !this.isVisible(checkModal)) {
          if (this.clickRetries === 0) {
            console.log("[InternHelper] Modal not detected after click. Trying synthetic click fallback.");
            this.clickRetries++;
            easyApplyBtn.dispatchEvent(new MouseEvent("click", { view: window, bubbles: true, cancelable: true }));
          }
        }
        return true;
      }
    }
    return false;
  }
  findSubmitButton() {
    const modal = document.querySelector('div[role="dialog"]');
    if (!modal) return null;
    const buttons = Array.from(modal.querySelectorAll("footer button, footer a"));
    return buttons.find((btn) => {
      var _a;
      return this.isVisible(btn) && (btn.innerText.toLowerCase().includes("submit application") || btn.innerText.toLowerCase() === "submit" || ((_a = btn.getAttribute("aria-label")) == null ? void 0 : _a.toLowerCase().includes("submit app")));
    });
  }
  findNextButton() {
    const modal = document.querySelector('div[role="dialog"]');
    if (!modal) return null;
    const errors = modal.querySelectorAll('[aria-invalid="true"]');
    if (errors.length > 0) return null;
    const buttons = Array.from(modal.querySelectorAll("footer button"));
    return buttons.find((btn) => {
      var _a, _b;
      return this.isVisible(btn) && (btn.innerText.toLowerCase() === "next" || btn.innerText.toLowerCase() === "review" || ((_a = btn.getAttribute("aria-label")) == null ? void 0 : _a.toLowerCase().includes("next")) || ((_b = btn.getAttribute("aria-label")) == null ? void 0 : _b.toLowerCase().includes("review")));
    });
  }
  findEasyApplyButton() {
    const elements = Array.from(document.querySelectorAll("button, a"));
    const candidates = elements.filter((el) => this.isVisible(el) && (el.innerText || "").toLowerCase().includes("easy apply"));
    return candidates[0] || null;
  }
  normalizeText(text) {
    if (!text) return "";
    let clean = text.toLowerCase().replace(/[^\w\s]/gi, "").trim();
    const stopwords = ["how", "many", "do", "you", "have", "with", "in", "of", "for", "the", "a", "an", "is", "are", "what", "please", "indicate", "select"];
    clean = clean.split(/\s+/).filter((w) => !stopwords.includes(w)).join(" ");
    return clean;
  }
  calculateFuzzyScore(questionTokens, patternTokens) {
    let matches = 0;
    for (const pt of patternTokens) {
      if (questionTokens.includes(pt)) matches++;
    }
    return patternTokens.length > 0 ? matches / patternTokens.length : 0;
  }
  matchDatabaseAnswer(normalizedQ) {
    const qTokens = normalizedQ.split(/\s+/);
    const patterns = [
      { key: "first_name", words: ["first", "name"] },
      { key: "last_name", words: ["last", "name"] },
      { key: "city", words: ["city"] },
      { key: "city", words: ["location"] },
      { key: "phone", words: ["phone"] },
      { key: "phone", words: ["mobile"] },
      { key: "phone", words: ["number"] },
      { key: "phone", words: ["contact"] },
      { key: "email", words: ["email"] },
      { key: "linkedin_url", words: ["linkedin"] },
      { key: "portfolio_url", words: ["portfolio"] },
      { key: "portfolio_url", words: ["website"] },
      { key: "expected_stipend", words: ["salary"] },
      { key: "expected_stipend", words: ["stipend"] },
      { key: "expected_stipend", words: ["compensation"] },
      { key: "experience", words: ["experience"] },
      { key: "experience", words: ["years"] },
      { key: "notice_period", words: ["notice"] },
      { key: "available_from", words: ["start"] }
    ];
    let bestMatch = null;
    let highestScore = 0;
    for (const pat of patterns) {
      const score = this.calculateFuzzyScore(qTokens, pat.words);
      if (score > highestScore) {
        highestScore = score;
        bestMatch = pat.key;
      }
    }
    if (highestScore >= 0.3) {
      let val = this.profile[bestMatch];
      if (bestMatch === "first_name" && !val && this.profile.full_name) val = this.profile.full_name.split(" ")[0];
      if (bestMatch === "last_name" && !val && this.profile.full_name) val = this.profile.full_name.split(" ").slice(1).join(" ");
      return val;
    }
    return null;
  }
  extractNumberRequired(rawText) {
    const match = rawText.match(/\d+/);
    return match ? parseInt(match[0], 10) : 0;
  }
  async fillFields(containers) {
    for (const container of containers) {
      const rawLabelNode = container.querySelector("label, legend, span.t-14, strong");
      if (!rawLabelNode) {
        container.dataset.ihProcessed = "true";
        continue;
      }
      const rawQuestion = rawLabelNode.innerText || "";
      const normalized = this.normalizeText(rawQuestion);
      if (!normalized) {
        container.dataset.ihProcessed = "true";
        continue;
      }
      console.log(`[InternHelper] Parsing question: "${rawQuestion.substring(0, 40)}..."`);
      let targetValue = this.matchDatabaseAnswer(normalized);
      if (normalized.includes("experience") || normalized.includes("years")) {
        const requiredYears = this.extractNumberRequired(rawQuestion);
        const myExp = parseInt(this.profile.experience || "0", 10);
        if (requiredYears > myExp) {
          console.log(`[InternHelper] Refusing to exaggerate. Required: ${requiredYears}, Mine: ${myExp}`);
          targetValue = myExp;
        }
      }
      const radioInputs = Array.from(container.querySelectorAll('input[type="radio"]'));
      if (radioInputs.length > 0) {
        await this.handleRadios(radioInputs, normalized, targetValue);
        container.dataset.ihProcessed = "true";
        continue;
      }
      const selectBtn = container.querySelector('button[role="combobox"], select');
      if (selectBtn && this.isVisible(selectBtn)) {
        await this.handleSelect(selectBtn, targetValue);
        container.dataset.ihProcessed = "true";
        continue;
      }
      const textInput = container.querySelector('input[type="text"], input[type="email"], input[type="tel"], textarea, input[type="number"], input:not([type])');
      if (textInput && this.isVisible(textInput) && !textInput.dataset.ihFilled) {
        let valToInject = targetValue;
        if (valToInject == null) {
          if (textInput.type === "number") valToInject = 0;
          else valToInject = "I am very interested in this opportunity and believe my skills align well with the role.";
        }
        this.setNativeReactValue(textInput, String(valToInject));
        textInput.dataset.ihFilled = "true";
        await this.randomDelay(400, 800);
      }
      container.dataset.ihProcessed = "true";
    }
  }
  async handleRadios(radioInputs, normalizedQuestion, fuzzyMatchedValue) {
    let clicked = false;
    let fallbackToYes = normalizedQuestion.includes("authorized") || normalizedQuestion.includes("relocate");
    let fallbackToNo = normalizedQuestion.includes("sponsorship");
    for (const radio of radioInputs) {
      const id = radio.id;
      const labelEl = radio.parentElement.querySelector(`label[for="${id}"]`) || radio.nextElementSibling || radio.parentElement;
      const rText = ((labelEl == null ? void 0 : labelEl.innerText) || radio.value || "").toLowerCase();
      if (typeof fuzzyMatchedValue === "boolean") {
        if (fuzzyMatchedValue && rText.includes("yes") || !fuzzyMatchedValue && rText.includes("no")) {
          labelEl.click();
          clicked = true;
          break;
        }
      } else if (fuzzyMatchedValue != null && rText.includes(String(fuzzyMatchedValue).toLowerCase())) {
        labelEl.click();
        clicked = true;
        break;
      } else if (fallbackToYes && rText.includes("yes")) {
        labelEl.click();
        clicked = true;
        break;
      } else if (fallbackToNo && rText.includes("no")) {
        labelEl.click();
        clicked = true;
        break;
      }
    }
    if (!clicked && radioInputs.length > 0) {
      const id = radioInputs[0].id;
      const backupLabel = radioInputs[0].parentElement.querySelector(`label[for="${id}"]`) || radioInputs[0].parentElement;
      backupLabel.click();
    }
    await this.randomDelay(400, 800);
  }
  async handleSelect(selectBtn, targetValue) {
    var _a;
    if (selectBtn.dataset.ihFilled) return;
    if (selectBtn.tagName.toLowerCase() === "select") {
      this.setNativeReactValue(selectBtn, targetValue || ((_a = selectBtn.options[1]) == null ? void 0 : _a.value) || "");
    } else {
      selectBtn.click();
      await this.randomDelay(500, 800);
      const listbox = document.querySelector('[role="listbox"]');
      if (listbox) {
        const options = Array.from(listbox.querySelectorAll('li[role="option"], li.artdeco-dropdown__item')).filter((o) => o.getAttribute("aria-disabled") !== "true" && o.offsetParent !== null);
        let targetOption = null;
        if (targetValue != null) {
          targetOption = options.find((o) => o.innerText.toLowerCase().includes(String(targetValue).toLowerCase()));
        }
        if (!targetOption && options.length > 0) {
          targetOption = options[0];
        }
        if (targetOption) targetOption.click();
        else document.body.click();
      }
    }
    selectBtn.dataset.ihFilled = "true";
    await this.randomDelay(500, 900);
  }
  setNativeReactValue(element, value) {
    var _a, _b;
    try {
      const valueSetter = (_a = Object.getOwnPropertyDescriptor(element.__proto__, "value")) == null ? void 0 : _a.set;
      const prototypeSetter = (_b = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(element), "value")) == null ? void 0 : _b.set;
      const setter = valueSetter || prototypeSetter;
      if (setter) setter.call(element, value);
      else element.value = value;
      element.dispatchEvent(new Event("input", { bubbles: true }));
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } catch (e) {
      console.error("[InternHelper] React Native Injection Failed:", e);
    }
  }
}
if (!window.__INTERN_HELPER_LISTENER_BOUND) {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "START_AUTOFILL" || message.type === "START_AUTOMATION") {
      if (window.__INTERN_HELPER_ENGINE) {
        console.log("[InternHelper] Automation already running.");
        return;
      }
      const profile = message.profile || {};
      const engine = new AutomationController(profile);
      window.__INTERN_HELPER_ENGINE = engine;
      engine.start();
    }
  });
  window.__INTERN_HELPER_LISTENER_BOUND = true;
}
chrome.storage.local.get(["sessionState", "profile"], (result) => {
  var _a, _b, _c;
  const state = result.sessionState;
  const profile = result.profile || {};
  if (state && state.isActive && !state.isPaused) {
    if (!window.location.href.includes("/jobs/view/")) return;
    if (window.__INTERN_HELPER_LOCK) return;
    window.__INTERN_HELPER_LOCK = true;
    const currentUrl = location.href.split("?")[0];
    const targetUrl = (_c = (_b = (_a = state.queue) == null ? void 0 : _a[state.currentIndex]) == null ? void 0 : _b.jobUrl) == null ? void 0 : _c.split("?")[0];
    if (currentUrl === targetUrl) {
      console.log(`[InternHelper] Resuming Reactive session.`);
      setTimeout(() => {
        if (!window.__INTERN_HELPER_ENGINE) {
          const engine = new AutomationController(profile);
          window.__INTERN_HELPER_ENGINE = engine;
          engine.start();
        }
      }, 3e3);
    }
  }
});
//# sourceMappingURL=guided_apply.js-Dw1NUhfY.js.map
})()